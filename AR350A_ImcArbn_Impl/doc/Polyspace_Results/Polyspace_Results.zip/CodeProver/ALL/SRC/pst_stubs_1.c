#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */

/*
 * _stub_p_g_53
 */

#pragma POLYSPACE_POLYMORPHIC "_stub_p_g_53"


static __PST__UINT32 _stub_p_g_53(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct Rte_CDS_ImcArbn _main_gen_init_g58(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct __PST__g__51 _main_gen_init_g51(void);

struct __PST__g__51 _main_gen_init_g51(void)
{
    static struct __PST__g__51 x;
    /* struct/union type */
    /* function pointer */
    x.GetSigValOper = PST_TRUE() ? 0 : _stub_p_g_53;
    x.SigId_u16 = _main_gen_init_g7();
    x.DestSize_u08 = _main_gen_init_g6();
    x.StrtLocn_u08 = _main_gen_init_g6();
    return x;
}

struct Rte_CDS_ImcArbn _main_gen_init_g58(void)
{
    static struct Rte_CDS_ImcArbn x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__60 _main_gen_tmp_91[ARRAY_NBELEM(__PST__g__60)];
        __PST__UINT32 _i_main_gen_tmp_92;
        for (_i_main_gen_tmp_92 = 0; _i_main_gen_tmp_92 < ARRAY_NBELEM(__PST__g__60); _i_main_gen_tmp_92++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_93_0;
                
                for (_main_gen_tmp_93_0 = 0; _main_gen_tmp_93_0 < 2; _main_gen_tmp_93_0++)
                {
                    __PST__UINT32 _main_gen_tmp_93_1;
                    
                    for (_main_gen_tmp_93_1 = 0; _main_gen_tmp_93_1 < 2; _main_gen_tmp_93_1++)
                    {
                        /* base type */
                        _main_gen_tmp_91[_i_main_gen_tmp_92][_main_gen_tmp_93_0][_main_gen_tmp_93_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_FrmFltCntr100MilliSec = PST_TRUE() ? 0 : &_main_gen_tmp_91[ARRAY_NBELEM(__PST__g__60) / 2];
    }
    /* pointer */
    {
        static __PST__g__60 _main_gen_tmp_94[ARRAY_NBELEM(__PST__g__60)];
        __PST__UINT32 _i_main_gen_tmp_95;
        for (_i_main_gen_tmp_95 = 0; _i_main_gen_tmp_95 < ARRAY_NBELEM(__PST__g__60); _i_main_gen_tmp_95++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_96_0;
                
                for (_main_gen_tmp_96_0 = 0; _main_gen_tmp_96_0 < 2; _main_gen_tmp_96_0++)
                {
                    __PST__UINT32 _main_gen_tmp_96_1;
                    
                    for (_main_gen_tmp_96_1 = 0; _main_gen_tmp_96_1 < 2; _main_gen_tmp_96_1++)
                    {
                        /* base type */
                        _main_gen_tmp_94[_i_main_gen_tmp_95][_main_gen_tmp_96_0][_main_gen_tmp_96_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_FrmFltCntr10MilliSec = PST_TRUE() ? 0 : &_main_gen_tmp_94[ARRAY_NBELEM(__PST__g__60) / 2];
    }
    /* pointer */
    {
        static __PST__g__60 _main_gen_tmp_97[ARRAY_NBELEM(__PST__g__60)];
        __PST__UINT32 _i_main_gen_tmp_98;
        for (_i_main_gen_tmp_98 = 0; _i_main_gen_tmp_98 < ARRAY_NBELEM(__PST__g__60); _i_main_gen_tmp_98++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_99_0;
                
                for (_main_gen_tmp_99_0 = 0; _main_gen_tmp_99_0 < 2; _main_gen_tmp_99_0++)
                {
                    __PST__UINT32 _main_gen_tmp_99_1;
                    
                    for (_main_gen_tmp_99_1 = 0; _main_gen_tmp_99_1 < 2; _main_gen_tmp_99_1++)
                    {
                        /* base type */
                        _main_gen_tmp_97[_i_main_gen_tmp_98][_main_gen_tmp_99_0][_main_gen_tmp_99_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_FrmFltCntr2MilliSec = PST_TRUE() ? 0 : &_main_gen_tmp_97[ARRAY_NBELEM(__PST__g__60) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_100[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_101;
        for (_i_main_gen_tmp_101 = 0; _i_main_gen_tmp_101 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_101++)
        {
            _main_gen_tmp_100[_i_main_gen_tmp_101] = _main_gen_init_g8();
        }
        x.Pim_ImcEcuComStrtTiRef = PST_TRUE() ? 0 : &_main_gen_tmp_100[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_102[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_103;
        for (_i_main_gen_tmp_103 = 0; _i_main_gen_tmp_103 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_103++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_104_0;
                
                for (_main_gen_tmp_104_0 = 0; _main_gen_tmp_104_0 < 5; _main_gen_tmp_104_0++)
                {
                    /* base type */
                    _main_gen_tmp_102[_i_main_gen_tmp_103][_main_gen_tmp_104_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_PrevRollgCntrRxd = PST_TRUE() ? 0 : &_main_gen_tmp_102[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_105[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_106;
        for (_i_main_gen_tmp_106 = 0; _i_main_gen_tmp_106 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_106++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_107_0;
                
                for (_main_gen_tmp_107_0 = 0; _main_gen_tmp_107_0 < 5; _main_gen_tmp_107_0++)
                {
                    /* base type */
                    _main_gen_tmp_105[_i_main_gen_tmp_106][_main_gen_tmp_107_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_PrimSrcResyncCntr = PST_TRUE() ? 0 : &_main_gen_tmp_105[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_108[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_109;
        for (_i_main_gen_tmp_109 = 0; _i_main_gen_tmp_109 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_109++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_110_0;
                
                for (_main_gen_tmp_110_0 = 0; _main_gen_tmp_110_0 < 5; _main_gen_tmp_110_0++)
                {
                    /* base type */
                    _main_gen_tmp_108[_i_main_gen_tmp_109][_main_gen_tmp_110_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_PrimSrcRollgCntrResync = PST_TRUE() ? 0 : &_main_gen_tmp_108[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__65 _main_gen_tmp_111[ARRAY_NBELEM(__PST__g__65)];
        __PST__UINT32 _i_main_gen_tmp_112;
        for (_i_main_gen_tmp_112 = 0; _i_main_gen_tmp_112 < ARRAY_NBELEM(__PST__g__65); _i_main_gen_tmp_112++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_113_0;
                
                for (_main_gen_tmp_113_0 = 0; _main_gen_tmp_113_0 < 5; _main_gen_tmp_113_0++)
                {
                    __PST__UINT32 _main_gen_tmp_113_1;
                    
                    for (_main_gen_tmp_113_1 = 0; _main_gen_tmp_113_1 < 8; _main_gen_tmp_113_1++)
                    {
                        /* base type */
                        _main_gen_tmp_111[_i_main_gen_tmp_112][_main_gen_tmp_113_0][_main_gen_tmp_113_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_PrimSrcRxBuf = PST_TRUE() ? 0 : &_main_gen_tmp_111[ARRAY_NBELEM(__PST__g__65) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_114[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_115;
        for (_i_main_gen_tmp_115 = 0; _i_main_gen_tmp_115 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_115++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_116_0;
                
                for (_main_gen_tmp_116_0 = 0; _main_gen_tmp_116_0 < 5; _main_gen_tmp_116_0++)
                {
                    /* base type */
                    _main_gen_tmp_114[_i_main_gen_tmp_115][_main_gen_tmp_116_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_ResyncOnPrimActv = PST_TRUE() ? 0 : &_main_gen_tmp_114[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_117[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_118;
        for (_i_main_gen_tmp_118 = 0; _i_main_gen_tmp_118 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_118++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_119_0;
                
                for (_main_gen_tmp_119_0 = 0; _main_gen_tmp_119_0 < 5; _main_gen_tmp_119_0++)
                {
                    /* base type */
                    _main_gen_tmp_117[_i_main_gen_tmp_118][_main_gen_tmp_119_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_ResyncOnSecdryActv = PST_TRUE() ? 0 : &_main_gen_tmp_117[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__68 _main_gen_tmp_120[ARRAY_NBELEM(__PST__g__68)];
        __PST__UINT32 _i_main_gen_tmp_121;
        for (_i_main_gen_tmp_121 = 0; _i_main_gen_tmp_121 < ARRAY_NBELEM(__PST__g__68); _i_main_gen_tmp_121++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_122_0;
                
                for (_main_gen_tmp_122_0 = 0; _main_gen_tmp_122_0 < 3; _main_gen_tmp_122_0++)
                {
                    /* base type */
                    _main_gen_tmp_120[_i_main_gen_tmp_121][_main_gen_tmp_122_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_RollgCntr = PST_TRUE() ? 0 : &_main_gen_tmp_120[ARRAY_NBELEM(__PST__g__68) / 2];
    }
    /* pointer */
    {
        static __PST__g__70 _main_gen_tmp_123[ARRAY_NBELEM(__PST__g__70)];
        __PST__UINT32 _i_main_gen_tmp_124;
        for (_i_main_gen_tmp_124 = 0; _i_main_gen_tmp_124 < ARRAY_NBELEM(__PST__g__70); _i_main_gen_tmp_124++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_125_0;
                
                for (_main_gen_tmp_125_0 = 0; _main_gen_tmp_125_0 < 8; _main_gen_tmp_125_0++)
                {
                    /* base type */
                    _main_gen_tmp_123[_i_main_gen_tmp_124][_main_gen_tmp_125_0] = pst_random_g_8;
                }
            }
        }
        x.Pim_RxdSigData = PST_TRUE() ? 0 : &_main_gen_tmp_123[ARRAY_NBELEM(__PST__g__70) / 2];
    }
    /* pointer */
    {
        static __PST__g__66 _main_gen_tmp_126[ARRAY_NBELEM(__PST__g__66)];
        __PST__UINT32 _i_main_gen_tmp_127;
        for (_i_main_gen_tmp_127 = 0; _i_main_gen_tmp_127 < ARRAY_NBELEM(__PST__g__66); _i_main_gen_tmp_127++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_128_0;
                
                for (_main_gen_tmp_128_0 = 0; _main_gen_tmp_128_0 < 8; _main_gen_tmp_128_0++)
                {
                    /* base type */
                    _main_gen_tmp_126[_i_main_gen_tmp_127][_main_gen_tmp_128_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_RxdSigDataExtdSts = PST_TRUE() ? 0 : &_main_gen_tmp_126[ARRAY_NBELEM(__PST__g__66) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_129[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_130;
        for (_i_main_gen_tmp_130 = 0; _i_main_gen_tmp_130 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_130++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_131_0;
                
                for (_main_gen_tmp_131_0 = 0; _main_gen_tmp_131_0 < 5; _main_gen_tmp_131_0++)
                {
                    /* base type */
                    _main_gen_tmp_129[_i_main_gen_tmp_130][_main_gen_tmp_131_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_RxdSigDataSrc = PST_TRUE() ? 0 : &_main_gen_tmp_129[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_132[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_133;
        for (_i_main_gen_tmp_133 = 0; _i_main_gen_tmp_133 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_133++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_134_0;
                
                for (_main_gen_tmp_134_0 = 0; _main_gen_tmp_134_0 < 5; _main_gen_tmp_134_0++)
                {
                    /* base type */
                    _main_gen_tmp_132[_i_main_gen_tmp_133][_main_gen_tmp_134_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SecdrySrcResyncCntr = PST_TRUE() ? 0 : &_main_gen_tmp_132[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_135[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_136;
        for (_i_main_gen_tmp_136 = 0; _i_main_gen_tmp_136 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_136++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_137_0;
                
                for (_main_gen_tmp_137_0 = 0; _main_gen_tmp_137_0 < 5; _main_gen_tmp_137_0++)
                {
                    /* base type */
                    _main_gen_tmp_135[_i_main_gen_tmp_136][_main_gen_tmp_137_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SecdrySrcRollgCntrResync = PST_TRUE() ? 0 : &_main_gen_tmp_135[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__65 _main_gen_tmp_138[ARRAY_NBELEM(__PST__g__65)];
        __PST__UINT32 _i_main_gen_tmp_139;
        for (_i_main_gen_tmp_139 = 0; _i_main_gen_tmp_139 < ARRAY_NBELEM(__PST__g__65); _i_main_gen_tmp_139++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_140_0;
                
                for (_main_gen_tmp_140_0 = 0; _main_gen_tmp_140_0 < 5; _main_gen_tmp_140_0++)
                {
                    __PST__UINT32 _main_gen_tmp_140_1;
                    
                    for (_main_gen_tmp_140_1 = 0; _main_gen_tmp_140_1 < 8; _main_gen_tmp_140_1++)
                    {
                        /* base type */
                        _main_gen_tmp_138[_i_main_gen_tmp_139][_main_gen_tmp_140_0][_main_gen_tmp_140_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_SecdrySrcRxBuf = PST_TRUE() ? 0 : &_main_gen_tmp_138[ARRAY_NBELEM(__PST__g__65) / 2];
    }
    /* pointer */
    {
        static __PST__g__66 _main_gen_tmp_141[ARRAY_NBELEM(__PST__g__66)];
        __PST__UINT32 _i_main_gen_tmp_142;
        for (_i_main_gen_tmp_142 = 0; _i_main_gen_tmp_142 < ARRAY_NBELEM(__PST__g__66); _i_main_gen_tmp_142++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_143_0;
                
                for (_main_gen_tmp_143_0 = 0; _main_gen_tmp_143_0 < 8; _main_gen_tmp_143_0++)
                {
                    /* base type */
                    _main_gen_tmp_141[_i_main_gen_tmp_142][_main_gen_tmp_143_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SigGroupDataSrc = PST_TRUE() ? 0 : &_main_gen_tmp_141[ARRAY_NBELEM(__PST__g__66) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_144[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_145;
        for (_i_main_gen_tmp_145 = 0; _i_main_gen_tmp_145 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_145++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_146_0;
                
                for (_main_gen_tmp_146_0 = 0; _main_gen_tmp_146_0 < 5; _main_gen_tmp_146_0++)
                {
                    /* base type */
                    _main_gen_tmp_144[_i_main_gen_tmp_145][_main_gen_tmp_146_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SigGroupMissCntr = PST_TRUE() ? 0 : &_main_gen_tmp_144[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_147[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_148;
        for (_i_main_gen_tmp_148 = 0; _i_main_gen_tmp_148 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_148++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_149_0;
                
                for (_main_gen_tmp_149_0 = 0; _main_gen_tmp_149_0 < 5; _main_gen_tmp_149_0++)
                {
                    /* base type */
                    _main_gen_tmp_147[_i_main_gen_tmp_148][_main_gen_tmp_149_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SigGroupNeverRxd = PST_TRUE() ? 0 : &_main_gen_tmp_147[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__63 _main_gen_tmp_150[ARRAY_NBELEM(__PST__g__63)];
        __PST__UINT32 _i_main_gen_tmp_151;
        for (_i_main_gen_tmp_151 = 0; _i_main_gen_tmp_151 < ARRAY_NBELEM(__PST__g__63); _i_main_gen_tmp_151++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_152_0;
                
                for (_main_gen_tmp_152_0 = 0; _main_gen_tmp_152_0 < 5; _main_gen_tmp_152_0++)
                {
                    /* base type */
                    _main_gen_tmp_150[_i_main_gen_tmp_151][_main_gen_tmp_152_0] = pst_random_g_6;
                }
            }
        }
        x.Pim_SigGroupSkipCntr = PST_TRUE() ? 0 : &_main_gen_tmp_150[ARRAY_NBELEM(__PST__g__63) / 2];
    }
    /* pointer */
    {
        static __PST__g__65 _main_gen_tmp_153[ARRAY_NBELEM(__PST__g__65)];
        __PST__UINT32 _i_main_gen_tmp_154;
        for (_i_main_gen_tmp_154 = 0; _i_main_gen_tmp_154 < ARRAY_NBELEM(__PST__g__65); _i_main_gen_tmp_154++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_155_0;
                
                for (_main_gen_tmp_155_0 = 0; _main_gen_tmp_155_0 < 5; _main_gen_tmp_155_0++)
                {
                    __PST__UINT32 _main_gen_tmp_155_1;
                    
                    for (_main_gen_tmp_155_1 = 0; _main_gen_tmp_155_1 < 8; _main_gen_tmp_155_1++)
                    {
                        /* base type */
                        _main_gen_tmp_153[_i_main_gen_tmp_154][_main_gen_tmp_155_0][_main_gen_tmp_155_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_TxBuf = PST_TRUE() ? 0 : &_main_gen_tmp_153[ARRAY_NBELEM(__PST__g__65) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_SIGGROUPCONFIG_REC(void)
{
    extern __PST__g__46 SIGGROUPCONFIG_REC;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_86_0;
            
            for (_main_gen_tmp_86_0 = 0; _main_gen_tmp_86_0 < 5; _main_gen_tmp_86_0++)
            {
                /* struct/union type */
                /* pointer */
                {
                    static struct __PST__g__51 _main_gen_tmp_87[ARRAY_NBELEM(struct __PST__g__51)];
                    __PST__UINT32 _i_main_gen_tmp_88;
                    for (_i_main_gen_tmp_88 = 0; _i_main_gen_tmp_88 < ARRAY_NBELEM(struct __PST__g__51); _i_main_gen_tmp_88++)
                    {
                        _main_gen_tmp_87[_i_main_gen_tmp_88] = _main_gen_init_g51();
                    }
                    SIGGROUPCONFIG_REC[_main_gen_tmp_86_0].SigPrm = PST_TRUE() ? 0 : &_main_gen_tmp_87[ARRAY_NBELEM(struct __PST__g__51) / 2];
                }
                SIGGROUPCONFIG_REC[_main_gen_tmp_86_0].NrOfSig_u08 = _main_gen_init_g6();
                SIGGROUPCONFIG_REC[_main_gen_tmp_86_0].SigGroupId_u08 = _main_gen_init_g6();
                SIGGROUPCONFIG_REC[_main_gen_tmp_86_0].PrimSrcOnlySigGroup_logl = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_Rte_Inst_ImcArbn(void)
{
    extern __PST__g__55 Rte_Inst_ImcArbn;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_ImcArbn _main_gen_tmp_89[ARRAY_NBELEM(struct Rte_CDS_ImcArbn)];
            __PST__UINT32 _i_main_gen_tmp_90;
            for (_i_main_gen_tmp_90 = 0; _i_main_gen_tmp_90 < ARRAY_NBELEM(struct Rte_CDS_ImcArbn); _i_main_gen_tmp_90++)
            {
                _main_gen_tmp_89[_i_main_gen_tmp_90] = _main_gen_init_g58();
            }
            Rte_Inst_ImcArbn = PST_TRUE() ? 0 : &_main_gen_tmp_89[ARRAY_NBELEM(struct Rte_CDS_ImcArbn) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable SIGGROUPCONFIG_REC */
    _main_gen_init_sym_SIGGROUPCONFIG_REC();
    
    /* init for variable Rte_Inst_ImcArbn */
    _main_gen_init_sym_Rte_Inst_ImcArbn();
    
}
