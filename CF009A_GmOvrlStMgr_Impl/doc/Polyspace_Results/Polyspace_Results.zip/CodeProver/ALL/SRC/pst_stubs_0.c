#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_AbsActvProtd_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_ApaEna_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_ApaEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_EscEna_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_EscEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_EscLimdActv_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_EscLimdActv_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgEotCcw_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwAgEotCw_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgEotCw_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwAgTar_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTar_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwAgTraj_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTraj_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwAgTrajEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwHaptcEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_HwTq_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_HwTq_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_LkaEna_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_LkaEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_LkaTqCmdCdnd_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_LoaSt_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_LoaSt_Val(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg17DBusHiSpdMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusChassisExpInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusChassisExpMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusHiSpdInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg180BusHiSpdMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1E9BusHiSpdMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg1F5BusHiSpdInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg214BusHiSpdInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg214BusHiSpdMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg337BusChassisExpInvld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_Msg337BusChassisExpMiss_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_ShiftLvrRvs_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_SysSt_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_SysSt_Val(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehSpd_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpd_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMax_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMaxVld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMin_Val(__PST__g__37 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehSpdSecurMinVld_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl
 */


__PST__UINT8 Rte_Read_GmOvrlStMgr_VehStabyEnhmtActv_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl"


__PST__UINT8 Rte_Write_GmOvrlStMgr_ApaDrvrIntvDetd_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_ApaSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_ApaSt_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_ApaSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_EscSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_EscSt_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_EscSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwAgServoCmd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwAgServoEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwOscnEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwOscnEna_Logl"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnEna_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwOscnFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwOscnFrq_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnFrq_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwOscnMotAmp_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_HwTqOscSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_HwTqOscSt_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_HwTqOscSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_GmOvrlStMgr_LkaSt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_GmOvrlStMgr_LkaSt_Val"


__PST__UINT8 Rte_Write_GmOvrlStMgr_LkaSt_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_GmOvrlStMgr_GetRefTmr100MicroSec32bit_Oper(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_GmOvrlStMgr_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__29 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus
 */


__PST__UINT8 Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_GetErrorStatus(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus"


__PST__UINT8 Rte_Call_GmOvrlStMgr_GmLoaIgnCntr_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_GmOvrlStMgr_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_GmOvrlStMgr_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_GmOvrlStMgr_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaVehSpdHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscVehSpdHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcAmp_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHwTqFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd1_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqThd2_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaVehSpdLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbTqMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbVehSpdMin_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnStrtHaptcAmp_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val"


__PST__FLOAT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHwTqTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcDurn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReactnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrHaptcReqTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd1_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaHwTqTiThd2_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOffTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbOnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnHaptcFbStrtOnTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrShiftLvrTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val"


__PST__UINT32 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrStandStillTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val"


__PST__UINT16 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaStIgnCntrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl"


__PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaHaptcEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl"


__PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrApaMfgEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl"


__PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrEscMfgEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl"


__PST__UINT8 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLkaMfgEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D"


__PST__g__48 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnTqOscnAmpY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D"


__PST__g__48 Rte_Prm_GmOvrlStMgr_GmOvrlStMgrLoaMtgtnVehSpdX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__48 real_random_for_return ;
        __PST__g__48 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl"


__PST__VOID Rte_IrvWrite_GmOvrlStMgr_GmOvrlStMgrInit1_IgnCntrLcl(__PST__UINT16 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl"


__PST__UINT16 Rte_IrvRead_GmOvrlStMgr_GmOvrlStMgrPer1_IgnCntrLcl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__48 P_0, __PST__g__48 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

