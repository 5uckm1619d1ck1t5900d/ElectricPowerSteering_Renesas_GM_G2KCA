/**********************************************************************************************************************
* Copyright 2014 Nexteer 
* Nexteer Confidential
*
* Module File Name  : Compiler_Cfg.h
* Module Description: This file contains a stub header for UTP and QAC 
*                     projects
* Project           : CBD
* Author            : Lucas Wendling
***********************************************************************************************************************
* Version Control:
* %version:          %
* %derived_by:       %
*----------------------------------------------------------------------------
* Date      Rev      Author         Change Description
* -------   -------  --------  ----------------------------------------------
* 12/15/14  1.0      LWW       Initial EA4 version
**********************************************************************************************************************/
#ifndef COMPILER_CFG_H
#define COMPILER_CFG_H


#endif  /* COMPILER_CFG_H */

