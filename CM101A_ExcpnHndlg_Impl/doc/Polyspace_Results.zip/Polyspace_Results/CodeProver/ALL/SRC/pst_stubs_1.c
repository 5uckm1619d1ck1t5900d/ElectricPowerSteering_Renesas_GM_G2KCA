#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__535 _main_gen_init_g535(void);

extern struct __PST__g__533 _main_gen_init_g533(void);

extern __PST__g__529 _main_gen_init_g529(void);

extern union __PST__g__422 _main_gen_init_g422(void);

extern __PST__g__408 _main_gen_init_g408(void);

extern union __PST__g__403 _main_gen_init_g403(void);

extern struct __PST__g__393 _main_gen_init_g393(void);

extern union __PST__g__392 _main_gen_init_g392(void);

extern __PST__g__390 _main_gen_init_g390(void);

extern union __PST__g__385 _main_gen_init_g385(void);

extern struct __PST__g__383 _main_gen_init_g383(void);

extern union __PST__g__381 _main_gen_init_g381(void);

extern __PST__g__358 _main_gen_init_g358(void);

extern union __PST__g__349 _main_gen_init_g349(void);

extern union __PST__g__344 _main_gen_init_g344(void);

extern __PST__g__328 _main_gen_init_g328(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__324 _main_gen_init_g324(void);

extern __PST__g__320 _main_gen_init_g320(void);

extern union __PST__g__310 _main_gen_init_g310(void);

extern union __PST__g__308 _main_gen_init_g308(void);

extern __PST__g__306 _main_gen_init_g306(void);

extern union __PST__g__144 _main_gen_init_g144(void);

extern struct __PST__g__137 _main_gen_init_g137(void);

extern union __PST__g__135 _main_gen_init_g135(void);

extern struct __PST__g__130 _main_gen_init_g130(void);

extern union __PST__g__128 _main_gen_init_g128(void);

extern __PST__g__101 _main_gen_init_g101(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__77 _main_gen_init_g77(void);

extern union __PST__g__74 _main_gen_init_g74(void);

extern union __PST__g__72 _main_gen_init_g72(void);

extern union __PST__g__70 _main_gen_init_g70(void);

extern __PST__g__49 _main_gen_init_g49(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__38 _main_gen_init_g38(void);

extern union __PST__g__36 _main_gen_init_g36(void);

extern __PST__g__26 _main_gen_init_g26(void);

struct __PST__g__38 _main_gen_init_g38(void)
{
    static struct __PST__g__38 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.SSE001 = bitf;
    }
    return x;
}

union __PST__g__36 _main_gen_init_g36(void)
{
    static union __PST__g__36 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g38();
    return x;
}

__PST__g__26 _main_gen_init_g26(void)
{
    __PST__g__26 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g36();
    return x;
}

union __PST__g__70 _main_gen_init_g70(void)
{
    static union __PST__g__70 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__72 _main_gen_init_g72(void)
{
    static union __PST__g__72 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__74 _main_gen_init_g74(void)
{
    static union __PST__g__74 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__77 _main_gen_init_g77(void)
{
    static union __PST__g__77 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__49 _main_gen_init_g49(void)
{
    __PST__g__49 x;
    /* struct/union type */
    x.ESSTC0 = _main_gen_init_g70();
    x.ESSTC1 = _main_gen_init_g72();
    x.PCMD1 = _main_gen_init_g74();
    x.PS = _main_gen_init_g77();
    return x;
}

struct __PST__g__130 _main_gen_init_g130(void)
{
    static struct __PST__g__130 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODE = bitf;
    }
    return x;
}

union __PST__g__128 _main_gen_init_g128(void)
{
    static union __PST__g__128 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g130();
    return x;
}

struct __PST__g__137 _main_gen_init_g137(void)
{
    static struct __PST__g__137 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODEB = bitf;
    }
    return x;
}

union __PST__g__135 _main_gen_init_g135(void)
{
    static union __PST__g__135 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g137();
    return x;
}

union __PST__g__144 _main_gen_init_g144(void)
{
    static union __PST__g__144 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__101 _main_gen_init_g101(void)
{
    __PST__g__101 x;
    /* struct/union type */
    x.BSEQ0ST = _main_gen_init_g128();
    x.BSEQ0STB = _main_gen_init_g135();
    x.RESFC = _main_gen_init_g144();
    return x;
}

union __PST__g__308 _main_gen_init_g308(void)
{
    static union __PST__g__308 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__310 _main_gen_init_g310(void)
{
    static union __PST__g__310 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__306 _main_gen_init_g306(void)
{
    __PST__g__306 x;
    /* struct/union type */
    x.DAT0 = _main_gen_init_g308();
    x.DAT1 = _main_gen_init_g310();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__324 _main_gen_init_g324(void)
{
    static union __PST__g__324 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__320 _main_gen_init_g320(void)
{
    __PST__g__320 x;
    /* struct/union type */
    x.FLAG = _main_gen_init_g324();
    return x;
}

union __PST__g__344 _main_gen_init_g344(void)
{
    static union __PST__g__344 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__349 _main_gen_init_g349(void)
{
    static union __PST__g__349 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__328 _main_gen_init_g328(void)
{
    __PST__g__328 x;
    /* struct/union type */
    x.CF1STERSTR_PE1 = _main_gen_init_g344();
    x.CF1STEADR0_PE1 = _main_gen_init_g349();
    return x;
}

struct __PST__g__383 _main_gen_init_g383(void)
{
    static struct __PST__g__383 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF2 = bitf;
    }
    return x;
}

union __PST__g__381 _main_gen_init_g381(void)
{
    static union __PST__g__381 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g383();
    return x;
}

union __PST__g__385 _main_gen_init_g385(void)
{
    static union __PST__g__385 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__358 _main_gen_init_g358(void)
{
    __PST__g__358 x;
    /* struct/union type */
    x.LR1STERSTR_PE1 = _main_gen_init_g381();
    x.LR1STEADR0_PE1 = _main_gen_init_g385();
    x.LR1STEADR1_PE1 = _main_gen_init_g385();
    x.LR1STEADR2_PE1 = _main_gen_init_g385();
    x.LR1STEADR3_PE1 = _main_gen_init_g385();
    return x;
}

struct __PST__g__393 _main_gen_init_g393(void)
{
    static struct __PST__g__393 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ECDEDF0 = bitf;
    }
    return x;
}

union __PST__g__392 _main_gen_init_g392(void)
{
    static union __PST__g__392 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g393();
    return x;
}

union __PST__g__403 _main_gen_init_g403(void)
{
    static union __PST__g__403 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__390 _main_gen_init_g390(void)
{
    __PST__g__390 x;
    /* struct/union type */
    x.CTL = _main_gen_init_g392();
    x.EAD0 = _main_gen_init_g403();
    return x;
}

union __PST__g__422 _main_gen_init_g422(void)
{
    static union __PST__g__422 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__408 _main_gen_init_g408(void)
{
    __PST__g__408 x;
    /* struct/union type */
    x.DMACER = _main_gen_init_g422();
    return x;
}

struct __PST__g__535 _main_gen_init_g535(void)
{
    static struct __PST__g__535 x;
    /* struct/union type */
    x.FailedSupervisionRefCycles = _main_gen_init_g7();
    x.DeadlineViolationCnt = _main_gen_init_g7();
    x.ProgramFlowViolationCnt = _main_gen_init_g7();
    return x;
}

struct __PST__g__533 _main_gen_init_g533(void)
{
    static struct __PST__g__533 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__535 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__535)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__535); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g535();
        }
        x.EntityStatusGRef = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__535) / 2];
    }
    return x;
}

__PST__g__529 _main_gen_init_g529(void)
{
    __PST__g__529 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__533 _main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__533)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct __PST__g__533); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g533();
        }
        x.WdgMSupervisedEntityRef = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__533) / 2];
    }
    x.NrOfSupervisedEntities = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__26 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ECMC(void)
{
    extern __PST__g__26 ECMC;
    
    /* initialization with random value */
    {
        ECMC = _main_gen_init_g26();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__49 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g49();
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__101 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g101();
    }
}

static void _main_gen_init_sym_BRAM(void)
{
    extern __PST__g__306 BRAM;
    
    /* initialization with random value */
    {
        BRAM = _main_gen_init_g306();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__320 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g320();
    }
}

static void _main_gen_init_sym_ECCFLI(void)
{
    extern __PST__g__328 ECCFLI;
    
    /* initialization with random value */
    {
        ECCFLI = _main_gen_init_g328();
    }
}

static void _main_gen_init_sym_ECCCPU1(void)
{
    extern __PST__g__358 ECCCPU1;
    
    /* initialization with random value */
    {
        ECCCPU1 = _main_gen_init_g358();
    }
}

static void _main_gen_init_sym_ECCCSIH0(void)
{
    extern __PST__g__390 ECCCSIH0;
    
    /* initialization with random value */
    {
        ECCCSIH0 = _main_gen_init_g390();
    }
}

static void _main_gen_init_sym_ECCCSIH1(void)
{
    extern __PST__g__390 ECCCSIH1;
    
    /* initialization with random value */
    {
        ECCCSIH1 = _main_gen_init_g390();
    }
}

static void _main_gen_init_sym_ECCCSIH2(void)
{
    extern __PST__g__390 ECCCSIH2;
    
    /* initialization with random value */
    {
        ECCCSIH2 = _main_gen_init_g390();
    }
}

static void _main_gen_init_sym_ECCCSIH3(void)
{
    extern __PST__g__390 ECCCSIH3;
    
    /* initialization with random value */
    {
        ECCCSIH3 = _main_gen_init_g390();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__408 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g408();
    }
}

static void _main_gen_init_sym_WdgMConfig_Mode0(void)
{
    extern __PST__g__529 WdgMConfig_Mode0;
    
    /* initialization with random value */
    {
        WdgMConfig_Mode0 = _main_gen_init_g529();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECMC */
    _main_gen_init_sym_ECMC();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable BRAM */
    _main_gen_init_sym_BRAM();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
    /* init for variable ECCFLI */
    _main_gen_init_sym_ECCFLI();
    
    /* init for variable ECCCPU1 */
    _main_gen_init_sym_ECCCPU1();
    
    /* init for variable ECCCSIH0 */
    _main_gen_init_sym_ECCCSIH0();
    
    /* init for variable ECCCSIH1 */
    _main_gen_init_sym_ECCCSIH1();
    
    /* init for variable ECCCSIH2 */
    _main_gen_init_sym_ECCCSIH2();
    
    /* init for variable ECCCSIH3 */
    _main_gen_init_sym_ECCCSIH3();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable WdgMConfig_Mode0 */
    _main_gen_init_sym_WdgMConfig_Mode0();
    
}
