/* header file for contract folder of CM200A */
#ifndef CDD_MOTAG0MEAS_H
#define CDD_MOTAG0MEAS_H

#define  MOTAG0MEAS_MOTAG0TRSMSTRTININ_CNT_U32  ((uint32)2147680256u)  /* Used in DMA */
#define  MOTAG0MEAS_MOTAG0READPTRRST_CNT_U32         0U

#endif

