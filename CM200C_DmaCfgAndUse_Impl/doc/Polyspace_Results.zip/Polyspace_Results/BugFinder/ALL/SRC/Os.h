/* header file for contract folder of CM200A */

#ifndef OS_H
#define OS_H

#define Call_DmaRegInin DmaRegInin

#endif

