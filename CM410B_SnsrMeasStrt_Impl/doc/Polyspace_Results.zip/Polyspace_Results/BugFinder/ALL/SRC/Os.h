/*Stub file only for UTP, QAC, Polysapce purpose*/ 


extern void SnsrMeasStrtIrq();

#define ISR(x) void x(void)

