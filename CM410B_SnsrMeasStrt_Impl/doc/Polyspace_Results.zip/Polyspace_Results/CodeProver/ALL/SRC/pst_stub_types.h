typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef __PST__SINT8 __PST__g__97[2];
typedef __PST__SINT16 __PST__g__98[1];
union __PST__g__30
  {
    __PST__g__98 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
struct __PST__g__23
  {
    __PST__g__97 __pst_unused_field_0;
    __PST__g__97 __pst_unused_field_1;
    union __PST__g__30 IC0CKSEL1;
  };
typedef volatile struct __PST__g__23 __PST__g__22;
union __PST__g__24
  {
    __PST__g__98 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__25
  {
    __PST__UINT16 __pst_unused_field_0 : 4;
    __PST__UINT16 __pst_unused_field_1 : 4;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_3 : 2;
    __PST__UINT16 __pst_unused_field_4 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
  };
typedef __PST__UINT8 __PST__g__29[2];
struct __PST__g__31
  {
    __PST__UINT16 __pst_unused_field_0 : 4;
    __PST__UINT16 __pst_unused_field_1 : 4;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_3 : 2;
    __PST__UINT16 __pst_unused_field_4 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
  };
typedef const __PST__UINT32 __PST__g__34;
typedef __PST__SINT8 __PST__g__99[1];
typedef __PST__SINT8 __PST__g__54[3];
union __PST__g__46
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
union __PST__g__48
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__100[7];
union __PST__g__51
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
struct __PST__g__33
  {
    __PST__UINT32 CMP;
    __PST__g__34 CNT;
    __PST__g__99 __pst_unused_field_2;
    __PST__g__54 __pst_unused_field_3;
    __PST__g__99 __pst_unused_field_4;
    __PST__g__54 __pst_unused_field_5;
    __PST__g__99 __pst_unused_field_6;
    __PST__g__54 __pst_unused_field_7;
    union __PST__g__46 TS;
    __PST__g__54 __pst_unused_field_9;
    union __PST__g__48 TT;
    __PST__g__100 __pst_unused_field_11;
    union __PST__g__51 CTL;
    __PST__g__54 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__33 __PST__g__32;
union __PST__g__35
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__36
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__38[3];
union __PST__g__39
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__40
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__42
  {
    __PST__g__99 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__42 __PST__g__41;
struct __PST__g__44
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef const struct __PST__g__44 __PST__g__43;
struct __PST__g__47
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__49
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__50[7];
struct __PST__g__52
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__VOID __PST__g__55(__PST__SINT32);
typedef __PST__UINT16 __PST__g__56(void);
typedef __PST__VOID __PST__g__57(__PST__UINT32);
typedef const struct Rte_CDS_CDD_SnsrMeasStrt __PST__g__60;
typedef __PST__g__60 *__PST__g__59;
typedef const __PST__g__59 __PST__g__58;
typedef __PST__UINT32 *__PST__g__62;
struct Rte_CDS_CDD_SnsrMeasStrt
  {
    __PST__g__62 Pim_TqMsgTrigCnt;
  };
typedef __PST__g__32 *__PST__g__63;
typedef volatile union __PST__g__48 __PST__g__64;
typedef __PST__g__64 *__PST__g__65;
typedef volatile __PST__UINT8 __PST__g__66;
typedef __PST__g__66 *__PST__g__67;
typedef __PST__g__22 *__PST__g__68;
typedef volatile union __PST__g__30 __PST__g__69;
typedef __PST__g__69 *__PST__g__70;
typedef volatile __PST__UINT16 __PST__g__71;
typedef __PST__g__71 *__PST__g__72;
typedef volatile union __PST__g__51 __PST__g__73;
typedef __PST__g__73 *__PST__g__74;
typedef __PST__g__57 *__PST__g__75;
typedef volatile __PST__UINT32 __PST__g__76;
typedef __PST__g__76 *__PST__g__77;
typedef volatile __PST__g__34 __PST__g__78;
typedef __PST__g__78 *__PST__g__79;
typedef __PST__g__56 *__PST__g__80;
typedef volatile union __PST__g__46 __PST__g__81;
typedef __PST__g__81 *__PST__g__82;
typedef __PST__g__15 *__PST__g__83;
typedef const __PST__g__62 __PST__g__84;
typedef __PST__g__84 *__PST__g__85;
typedef volatile __PST__SINT32 __PST__g__86;
typedef __PST__SINT8 __PST__g__92(void);
typedef volatile __PST__SINT8 __PST__g__93;
typedef __PST__UINT8 __PST__g__94(void);
typedef __PST__SINT32 __PST__g__95(void);
typedef __PST__UINT32 __PST__g__96(void);
