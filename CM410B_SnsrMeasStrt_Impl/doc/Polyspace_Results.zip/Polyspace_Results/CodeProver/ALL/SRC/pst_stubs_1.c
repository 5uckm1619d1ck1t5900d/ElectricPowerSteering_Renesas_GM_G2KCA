#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct Rte_CDS_CDD_SnsrMeasStrt _main_gen_init_g61(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__48 _main_gen_init_g48(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__46 _main_gen_init_g46(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__30 _main_gen_init_g30(void);

extern __PST__g__22 _main_gen_init_g22(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__30 _main_gen_init_g30(void)
{
    static union __PST__g__30 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__g__22 _main_gen_init_g22(void)
{
    __PST__g__22 x;
    /* struct/union type */
    x.IC0CKSEL1 = _main_gen_init_g30();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__46 _main_gen_init_g46(void)
{
    static union __PST__g__46 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__48 _main_gen_init_g48(void)
{
    static union __PST__g__48 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__51 _main_gen_init_g51(void)
{
    static union __PST__g__51 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.TS = _main_gen_init_g46();
    x.TT = _main_gen_init_g48();
    x.CTL = _main_gen_init_g51();
    x.CMP = _main_gen_init_g8();
    x.CNT = _main_gen_init_g8();
    return x;
}

struct Rte_CDS_CDD_SnsrMeasStrt _main_gen_init_g61(void)
{
    static struct Rte_CDS_CDD_SnsrMeasStrt x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g8();
        }
        x.Pim_TqMsgTrigCnt = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_OSTM(void)
{
    extern __PST__g__22 OSTM;
    
    /* initialization with random value */
    {
        OSTM = _main_gen_init_g22();
    }
}

static void _main_gen_init_sym_OSTM0(void)
{
    extern __PST__g__32 OSTM0;
    
    /* initialization with random value */
    {
        OSTM0 = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_OSTM1(void)
{
    extern __PST__g__32 OSTM1;
    
    /* initialization with random value */
    {
        OSTM1 = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_Rte_Inst_CDD_SnsrMeasStrt(void)
{
    extern __PST__g__58 Rte_Inst_CDD_SnsrMeasStrt;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_SnsrMeasStrt _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_SnsrMeasStrt)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_SnsrMeasStrt); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g61();
            }
            Rte_Inst_CDD_SnsrMeasStrt = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_SnsrMeasStrt) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable OSTM */
    _main_gen_init_sym_OSTM();
    
    /* init for variable OSTM0 */
    _main_gen_init_sym_OSTM0();
    
    /* init for variable OSTM1 */
    _main_gen_init_sym_OSTM1();
    
    /* init for variable Rte_Inst_CDD_SnsrMeasStrt */
    _main_gen_init_sym_Rte_Inst_CDD_SnsrMeasStrt();
    
}
