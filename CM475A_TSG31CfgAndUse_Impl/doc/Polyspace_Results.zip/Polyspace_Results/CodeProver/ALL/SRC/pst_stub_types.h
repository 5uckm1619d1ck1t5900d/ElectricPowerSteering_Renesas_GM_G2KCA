typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__FLOAT64 __PST__g__16(void);
typedef __PST__g__11 *__PST__g__18;
typedef volatile __PST__FLOAT64 __PST__g__19;
typedef __PST__SINT8 *__PST__g__21;
typedef volatile __PST__g__21 __PST__g__20;
typedef const struct Rte_CDS_CDD_TSG31CfgAndUse __PST__g__24;
typedef __PST__g__24 *__PST__g__23;
typedef const __PST__g__23 __PST__g__22;
typedef __PST__UINT32 *__PST__g__26;
typedef __PST__UINT8 *__PST__g__27;
struct Rte_CDS_CDD_TSG31CfgAndUse
  {
    __PST__g__26 Pim_TSG31CfgAndUseAdcStrtOfCnvnPeak;
    __PST__g__26 Pim_TSG31CfgAndUseMotAg0SPIStart;
    __PST__g__27 Pim_TSG31CfgAndUseSysStEnaPrev;
  };
typedef __PST__SINT16 __PST__g__312[1];
union __PST__g__30
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__302[2];
typedef __PST__SINT8 __PST__g__304[1];
union __PST__g__35
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__303[3];
union __PST__g__39
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
union __PST__g__42
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
union __PST__g__59
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef const __PST__UINT16 __PST__g__66;
struct __PST__g__68
  {
    __PST__UINT8 TS : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
union __PST__g__67
  {
    struct __PST__g__68 BIT;
    __PST__UINT8 __pst_unused_field_1;
  };
union __PST__g__72
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__305[7];
typedef __PST__SINT8 __PST__g__306[4];
struct __PST__g__97
  {
    __PST__UINT32 DTC0 : 10;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 22;
  };
union __PST__g__96
  {
    struct __PST__g__97 BIT;
    __PST__UINT32 UINT32;
  };
struct __PST__g__101
  {
    __PST__UINT32 DTC1 : 10;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 22;
  };
union __PST__g__100
  {
    struct __PST__g__101 BIT;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT32 __PST__g__313[1];
union __PST__g__102
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__105
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__108
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__307[90];
typedef __PST__SINT8 __PST__g__308[8];
union __PST__g__126
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__128
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__130
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__132
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__134
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__136
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__140
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__142
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__144
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__158
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__160
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__162
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__309[88];
union __PST__g__181
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
union __PST__g__183
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
union __PST__g__185
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 UINT8;
  };
union __PST__g__187
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
struct __PST__g__190
  {
    __PST__UINT16 __pst_unused_field_0 : 15;
    __PST__UINT16 DTCM : 1;
  };
union __PST__g__189
  {
    struct __PST__g__190 BIT;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__310[6];
typedef __PST__SINT8 __PST__g__311[3555];
struct __PST__g__29
  {
    union __PST__g__30 IOC2;
    __PST__g__302 __pst_unused_field_1;
    union __PST__g__35 CTL3;
    __PST__g__303 __pst_unused_field_3;
    union __PST__g__39 CTL5;
    __PST__g__302 __pst_unused_field_5;
    union __PST__g__42 CTL6;
    __PST__g__302 __pst_unused_field_7;
    __PST__g__304 __pst_unused_field_8;
    __PST__g__303 __pst_unused_field_9;
    __PST__g__304 __pst_unused_field_10;
    __PST__g__303 __pst_unused_field_11;
    __PST__g__302 __pst_unused_field_12;
    __PST__g__302 __pst_unused_field_13;
    union __PST__g__59 STC;
    __PST__g__302 __pst_unused_field_15;
    __PST__g__304 __pst_unused_field_16;
    __PST__g__303 __pst_unused_field_17;
    __PST__g__304 __pst_unused_field_18;
    __PST__g__303 __pst_unused_field_19;
    __PST__g__66 __pst_unused_field_20;
    __PST__g__302 __pst_unused_field_21;
    __PST__g__66 __pst_unused_field_22;
    __PST__g__302 __pst_unused_field_23;
    union __PST__g__67 TRG0;
    __PST__g__303 __pst_unused_field_25;
    __PST__g__304 __pst_unused_field_26;
    __PST__g__303 __pst_unused_field_27;
    union __PST__g__72 TRG2;
    __PST__g__305 __pst_unused_field_29;
    __PST__g__306 __pst_unused_field_30;
    __PST__g__306 __pst_unused_field_31;
    __PST__g__306 __pst_unused_field_32;
    __PST__g__306 __pst_unused_field_33;
    __PST__g__306 __pst_unused_field_34;
    __PST__g__306 __pst_unused_field_35;
    __PST__UINT32 __pst_unused_field_36;
    __PST__g__306 __pst_unused_field_37;
    __PST__g__306 __pst_unused_field_38;
    __PST__g__306 __pst_unused_field_39;
    __PST__g__306 __pst_unused_field_40;
    union __PST__g__96 DTC0W;
    union __PST__g__100 DTC1W;
    union __PST__g__102 IOC3;
    union __PST__g__105 CTL2;
    union __PST__g__108 CTL4;
    __PST__UINT16 __pst_unused_field_46;
    __PST__g__302 __pst_unused_field_47;
    __PST__UINT16 __pst_unused_field_48;
    __PST__g__302 __pst_unused_field_49;
    __PST__UINT16 __pst_unused_field_50;
    __PST__g__302 __pst_unused_field_51;
    __PST__UINT16 __pst_unused_field_52;
    __PST__g__302 __pst_unused_field_53;
    __PST__UINT16 __pst_unused_field_54;
    __PST__g__302 __pst_unused_field_55;
    __PST__UINT16 __pst_unused_field_56;
    __PST__g__302 __pst_unused_field_57;
    __PST__UINT16 __pst_unused_field_58;
    __PST__g__302 __pst_unused_field_59;
    __PST__UINT16 __pst_unused_field_60;
    __PST__g__302 __pst_unused_field_61;
    __PST__UINT16 __pst_unused_field_62;
    __PST__g__302 __pst_unused_field_63;
    __PST__UINT16 __pst_unused_field_64;
    __PST__g__302 __pst_unused_field_65;
    __PST__UINT16 __pst_unused_field_66;
    __PST__g__302 __pst_unused_field_67;
    __PST__UINT16 __pst_unused_field_68;
    __PST__g__302 __pst_unused_field_69;
    __PST__UINT16 __pst_unused_field_70;
    __PST__g__302 __pst_unused_field_71;
    __PST__UINT16 __pst_unused_field_72;
    __PST__g__302 __pst_unused_field_73;
    __PST__UINT16 __pst_unused_field_74;
    __PST__g__302 __pst_unused_field_75;
    __PST__UINT16 __pst_unused_field_76;
    __PST__g__302 __pst_unused_field_77;
    __PST__UINT16 __pst_unused_field_78;
    __PST__g__302 __pst_unused_field_79;
    __PST__UINT16 __pst_unused_field_80;
    __PST__g__307 __pst_unused_field_81;
    __PST__g__306 __pst_unused_field_82;
    __PST__g__306 __pst_unused_field_83;
    __PST__g__306 __pst_unused_field_84;
    __PST__g__306 __pst_unused_field_85;
    __PST__g__306 __pst_unused_field_86;
    __PST__g__306 __pst_unused_field_87;
    __PST__g__308 __pst_unused_field_88;
    union __PST__g__126 DCMP2E;
    union __PST__g__128 DCMP1E;
    union __PST__g__130 DCMP0E;
    union __PST__g__132 CMP0E;
    union __PST__g__134 CMP12E;
    union __PST__g__136 CMP11E;
    __PST__g__306 __pst_unused_field_95;
    union __PST__g__140 CMP7E;
    union __PST__g__142 CMP4E;
    union __PST__g__144 CMP3E;
    __PST__g__306 __pst_unused_field_99;
    __PST__g__306 __pst_unused_field_100;
    __PST__g__306 __pst_unused_field_101;
    __PST__g__306 __pst_unused_field_102;
    __PST__g__306 __pst_unused_field_103;
    __PST__g__306 __pst_unused_field_104;
    union __PST__g__158 CMPWE;
    union __PST__g__160 CMPVE;
    union __PST__g__162 CMPUE;
    __PST__g__306 __pst_unused_field_108;
    __PST__g__306 __pst_unused_field_109;
    __PST__g__306 __pst_unused_field_110;
    __PST__g__306 __pst_unused_field_111;
    __PST__g__306 __pst_unused_field_112;
    __PST__g__306 __pst_unused_field_113;
    __PST__g__306 __pst_unused_field_114;
    __PST__g__309 __pst_unused_field_115;
    union __PST__g__181 IOC0;
    __PST__g__303 __pst_unused_field_117;
    union __PST__g__183 IOC1;
    __PST__g__303 __pst_unused_field_119;
    union __PST__g__185 CTL0;
    __PST__g__303 __pst_unused_field_121;
    union __PST__g__187 CTL1;
    __PST__g__302 __pst_unused_field_123;
    union __PST__g__189 DTPR;
    __PST__g__310 __pst_unused_field_125;
    __PST__g__304 __pst_unused_field_126;
    __PST__g__303 __pst_unused_field_127;
    __PST__g__304 __pst_unused_field_128;
    __PST__g__311 __pst_unused_field_129;
  };
typedef volatile struct __PST__g__29 __PST__g__28;
struct __PST__g__31
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 2;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_10 : 1;
    __PST__UINT16 __pst_unused_field_11 : 1;
    __PST__UINT16 __pst_unused_field_12 : 1;
    __PST__UINT16 __pst_unused_field_13 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef3 : 1;
  };
typedef __PST__UINT8 __PST__g__34[2];
struct __PST__g__36
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__38[3];
struct __PST__g__40
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_10 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 4;
  };
struct __PST__g__43
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_10 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__45
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__45 __PST__g__44;
struct __PST__g__47
  {
    const __PST__UINT8 __pst_unused_field_0 : 1;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    const __PST__UINT8 __pst_unused_field_2 : 1;
    const __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__47 __PST__g__46;
union __PST__g__50
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
typedef const union __PST__g__50 __PST__g__49;
struct __PST__g__52
  {
    const __PST__UINT8 __pst_unused_field_0 : 3;
    const __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 4;
  };
typedef const struct __PST__g__52 __PST__g__51;
union __PST__g__56
  {
    __PST__g__312 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
typedef const union __PST__g__56 __PST__g__55;
struct __PST__g__58
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT16 __pst_unused_field_1 : 1;
    const __PST__UINT16 __pst_unused_field_2 : 1;
    const __PST__UINT16 __pst_unused_field_3 : 1;
    const __PST__UINT16 __pst_unused_field_4 : 1;
    const __PST__UINT16 __pst_unused_field_5 : 1;
    const __PST__UINT16 __pst_unused_field_6 : 1;
    const __PST__UINT16 __pst_unused_field_7 : 1;
    const __PST__UINT16 __pst_unused_field_8 : 1;
    const __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 6;
  };
typedef const struct __PST__g__58 __PST__g__57;
struct __PST__g__60
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_9 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 6;
  };
union __PST__g__61
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__62
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 1;
  };
union __PST__g__63
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__64
  {
    __PST__UINT8 __pst_unused_field_0 : 3;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 5;
  };
union __PST__g__70
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__71
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
struct __PST__g__73
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__74[7];
union __PST__g__75
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__76
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__77
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__78
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__79
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__80
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__81
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__82
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__83
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__84
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__85
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__86
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__87
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__88
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 16;
  };
union __PST__g__89
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__90
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 16;
  };
union __PST__g__91
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__92
  {
    __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 3;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 3;
    __PST__UINT32 __pst_unused_field_5 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__94
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__95
  {
    __PST__UINT32 __pst_unused_field_0 : 3;
    __PST__UINT32 __pst_unused_field_1 : 3;
    __PST__UINT32 __pst_unused_field_2 : 3;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 3;
    __PST__UINT32 __pst_unused_field_5 : 3;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__103
  {
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 25;
  };
struct __PST__g__106
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 31;
  };
struct __PST__g__109
  {
    __PST__UINT32 __pst_unused_field_0 : 5;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 23;
  };
typedef __PST__UINT8 __PST__g__111[90];
union __PST__g__112
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__113
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__115
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__116
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__117
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__118
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__119
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__120
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__121
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__122
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__123
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__124
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
typedef __PST__UINT8 __PST__g__125[8];
struct __PST__g__127
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__129
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__131
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__133
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__135
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__137
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__138
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__139
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__141
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__143
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__145
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__146
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__147
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__148
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__149
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__150
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__151
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__152
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__153
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__154
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__155
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__156
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__157
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__159
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__161
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
struct __PST__g__163
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
typedef __PST__UINT8 __PST__g__164[4];
union __PST__g__165
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__166
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__167
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__168
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__169
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__170
  {
    __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
union __PST__g__172
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__172 __PST__g__171;
struct __PST__g__174
  {
    const __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
typedef const struct __PST__g__174 __PST__g__173;
union __PST__g__177
  {
    __PST__g__313 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef const union __PST__g__177 __PST__g__176;
struct __PST__g__179
  {
    const __PST__UINT32 __pst_unused_field_0 : 18;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 14;
  };
typedef const struct __PST__g__179 __PST__g__178;
typedef __PST__UINT8 __PST__g__180[88];
struct __PST__g__182
  {
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_5 : 1;
    __PST__UINT8 __pst_unused_field_6 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 1;
  };
struct __PST__g__184
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 3;
  };
struct __PST__g__186
  {
    __PST__UINT8 __pst_unused_field_0 : 3;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef2 : 3;
  };
struct __PST__g__188
  {
    __PST__UINT16 __pst_unused_field_0 : 2;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_2 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_4 : 1;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_6 : 1;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 6;
  };
typedef __PST__UINT8 __PST__g__192[6];
union __PST__g__193
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__194
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_2 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 5;
  };
union __PST__g__195
  {
    __PST__g__304 __pst_unused_field_0;
    __PST__UINT8 __pst_unused_field_1;
  };
struct __PST__g__196
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 7;
  };
typedef __PST__UINT8 __PST__g__197[3555];
typedef __PST__VOID __PST__g__198(__PST__SINT32);
typedef __PST__UINT8 __PST__g__199(__PST__g__27);
typedef __PST__UINT8 __PST__g__200(void);
typedef __PST__UINT8 __PST__g__201(__PST__UINT8);
typedef __PST__UINT32 __PST__g__202(void);
typedef __PST__UINT32 __PST__g__203(__PST__UINT32);
typedef __PST__g__15 *__PST__g__204;
typedef __PST__g__203 *__PST__g__205;
typedef __PST__g__202 *__PST__g__206;
typedef __PST__g__28 *__PST__g__207;
typedef volatile union __PST__g__100 __PST__g__208;
typedef __PST__g__208 *__PST__g__209;
typedef volatile struct __PST__g__101 __PST__g__210;
typedef __PST__g__210 *__PST__g__211;
typedef volatile union __PST__g__96 __PST__g__214;
typedef __PST__g__214 *__PST__g__215;
typedef volatile struct __PST__g__97 __PST__g__216;
typedef __PST__g__216 *__PST__g__217;
typedef volatile union __PST__g__132 __PST__g__218;
typedef __PST__g__218 *__PST__g__219;
typedef volatile __PST__UINT32 __PST__g__220;
typedef __PST__g__220 *__PST__g__221;
typedef volatile union __PST__g__162 __PST__g__222;
typedef __PST__g__222 *__PST__g__223;
typedef volatile union __PST__g__160 __PST__g__224;
typedef __PST__g__224 *__PST__g__225;
typedef volatile union __PST__g__158 __PST__g__226;
typedef __PST__g__226 *__PST__g__227;
typedef const __PST__g__26 __PST__g__228;
typedef __PST__g__228 *__PST__g__229;
typedef volatile union __PST__g__130 __PST__g__230;
typedef __PST__g__230 *__PST__g__231;
typedef volatile union __PST__g__134 __PST__g__232;
typedef __PST__g__232 *__PST__g__233;
typedef volatile union __PST__g__128 __PST__g__234;
typedef __PST__g__234 *__PST__g__235;
typedef volatile union __PST__g__140 __PST__g__236;
typedef __PST__g__236 *__PST__g__237;
typedef volatile union __PST__g__136 __PST__g__238;
typedef __PST__g__238 *__PST__g__239;
typedef volatile union __PST__g__185 __PST__g__240;
typedef __PST__g__240 *__PST__g__241;
typedef volatile __PST__UINT8 __PST__g__242;
typedef __PST__g__242 *__PST__g__243;
typedef volatile union __PST__g__187 __PST__g__244;
typedef __PST__g__244 *__PST__g__245;
typedef volatile __PST__UINT16 __PST__g__246;
typedef __PST__g__246 *__PST__g__247;
typedef volatile union __PST__g__105 __PST__g__248;
typedef __PST__g__248 *__PST__g__249;
typedef volatile union __PST__g__35 __PST__g__250;
typedef __PST__g__250 *__PST__g__251;
typedef volatile union __PST__g__108 __PST__g__252;
typedef __PST__g__252 *__PST__g__253;
typedef volatile union __PST__g__39 __PST__g__254;
typedef __PST__g__254 *__PST__g__255;
typedef volatile union __PST__g__42 __PST__g__256;
typedef __PST__g__256 *__PST__g__257;
typedef volatile union __PST__g__181 __PST__g__258;
typedef __PST__g__258 *__PST__g__259;
typedef volatile union __PST__g__183 __PST__g__260;
typedef __PST__g__260 *__PST__g__261;
typedef volatile union __PST__g__30 __PST__g__262;
typedef __PST__g__262 *__PST__g__263;
typedef volatile union __PST__g__102 __PST__g__264;
typedef __PST__g__264 *__PST__g__265;
typedef volatile union __PST__g__59 __PST__g__266;
typedef __PST__g__266 *__PST__g__267;
typedef volatile union __PST__g__72 __PST__g__268;
typedef __PST__g__268 *__PST__g__269;
typedef volatile union __PST__g__189 __PST__g__270;
typedef __PST__g__270 *__PST__g__271;
typedef volatile struct __PST__g__190 __PST__g__272;
typedef __PST__g__272 *__PST__g__273;
typedef volatile union __PST__g__67 __PST__g__276;
typedef __PST__g__276 *__PST__g__277;
typedef volatile struct __PST__g__68 __PST__g__278;
typedef __PST__g__278 *__PST__g__279;
typedef volatile union __PST__g__126 __PST__g__280;
typedef __PST__g__280 *__PST__g__281;
typedef volatile union __PST__g__142 __PST__g__282;
typedef __PST__g__282 *__PST__g__283;
typedef volatile union __PST__g__144 __PST__g__284;
typedef __PST__g__284 *__PST__g__285;
typedef __PST__g__199 *__PST__g__286;
typedef __PST__VOID __PST__g__287(__PST__UINT8);
typedef __PST__g__287 *__PST__g__288;
typedef const __PST__g__27 __PST__g__289;
typedef __PST__g__289 *__PST__g__290;
typedef __PST__g__201 *__PST__g__291;
typedef __PST__g__200 *__PST__g__292;
typedef volatile __PST__SINT32 __PST__g__293;
typedef __PST__SINT8 __PST__g__299(void);
typedef volatile __PST__SINT8 __PST__g__300;
typedef __PST__SINT32 __PST__g__301(void);
