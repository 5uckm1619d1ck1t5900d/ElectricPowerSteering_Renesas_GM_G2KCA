/* header file for contract folder of CM620C */

extern void GetMotAg3Mecl_Oper(u0p16 *MotAg0RawMecl);
