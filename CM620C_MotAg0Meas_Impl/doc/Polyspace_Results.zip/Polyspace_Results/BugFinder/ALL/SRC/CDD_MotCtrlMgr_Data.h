/* header file for contract folder of CM620C */

#ifndef CDD_MOTCTRLMGR_DATA_H
#define CDD_MOTCTRLMGR_DATA_H

extern uint32 MOTCTRLMGR_MotCtrlMotAgMeasTi;
extern uint16 MOTCTRLMGR_MotCtrlMotAg0Mecl;             /* Actual type is u0p16 */
extern sint32 MOTCTRLMGR_MotCtrlMotAg0Offs;

#endif

