typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__FLOAT32 *__PST__g__16;
typedef __PST__VOID __PST__g__15(__PST__g__16);
typedef const __PST__FLOAT32 __PST__g__19;
typedef __PST__g__19 *__PST__g__18;
typedef __PST__VOID __PST__g__17(__PST__g__18);
typedef __PST__VOID __PST__g__20(void);
typedef __PST__FLOAT64 __PST__g__21(void);
typedef __PST__g__11 *__PST__g__23;
typedef volatile __PST__FLOAT64 __PST__g__24;
typedef __PST__SINT8 *__PST__g__26;
typedef volatile __PST__g__26 __PST__g__25;
typedef const struct Rte_CDS_CDD_MotAg0Meas __PST__g__29;
typedef __PST__g__29 *__PST__g__28;
typedef const __PST__g__28 __PST__g__27;
typedef __PST__FLOAT32 __PST__g__32[26];
typedef __PST__g__32 *__PST__g__31;
typedef __PST__SINT8 __PST__g__34[128];
typedef __PST__g__34 *__PST__g__33;
typedef __PST__UINT16 *__PST__g__35;
typedef __PST__UINT8 *__PST__g__36;
typedef __PST__SINT32 *__PST__g__37;
typedef __PST__UINT32 *__PST__g__38;
typedef __PST__UINT32 __PST__g__40[10];
typedef __PST__g__40 *__PST__g__39;
struct Rte_CDS_CDD_MotAg0Meas
  {
    __PST__g__31 Pim_MotAg0CoeffTbl;
    __PST__g__33 Pim_MotAg0CorrnTbl;
    __PST__g__35 Pim_MotAg0Diagc;
    __PST__g__36 Pim_MotAg0InitOffs;
    __PST__g__37 Pim_MotAg0PrevOffs;
    __PST__g__36 Pim_MotAg0PrevRollgCntr;
    __PST__g__35 Pim_MotAg0PrevSpiErrFltCntr;
    __PST__g__35 Pim_dMotAg0MeasMotAg0Delta;
    __PST__g__38 Pim_dMotAg0MeasMotAg0RawAgReg;
    __PST__g__38 Pim_dMotAg0MeasMotAg0RawErrReg;
    __PST__g__39 Pim_dMotAg0MeasMotAg0RawReg;
    __PST__g__38 Pim_dMotAg0MeasMotAg0RawTurnCntrReg;
    __PST__g__37 Pim_dMotAg0MeasMotAg0RtOffs;
    __PST__g__35 Pim_dMotAg0MeasMotAg0SpiCntrAg;
    __PST__g__35 Pim_dMotAg0MeasMotAg0SpiMecl;
    __PST__g__16 Pim_dMotAg0MeasMotAg0TurnCntr;
    __PST__g__35 Pim_dMotAg0MeasMotCtrlMotAg3Mecl;
  };
struct __PST__g__44
  {
    __PST__UINT8 __pst_unused_field_0 : 1;
    __PST__UINT8 __pst_unused_field_1 : 1;
    __PST__UINT8 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT8 __pst_unused_field_3 : 1;
    __PST__UINT8 __pst_unused_field_4 : 1;
    __PST__UINT8 PWR : 1;
  };
union __PST__g__43
  {
    struct __PST__g__44 BIT;
    __PST__UINT8 UINT8;
  };
typedef __PST__SINT8 __PST__g__232[3];
typedef __PST__SINT32 __PST__g__237[1];
union __PST__g__49
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef const union __PST__g__49 __PST__g__48;
typedef __PST__SINT16 __PST__g__238[1];
union __PST__g__55
  {
    __PST__g__238 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__233[6];
union __PST__g__59
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__62
  {
    __PST__g__238 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
typedef __PST__SINT8 __PST__g__234[4074];
union __PST__g__65
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__69
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__71
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__110[2];
union __PST__g__76
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
union __PST__g__84
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
typedef __PST__SINT8 __PST__g__235[36];
union __PST__g__87
  {
    __PST__g__238 __pst_unused_field_0;
    __PST__UINT16 UINT16;
  };
union __PST__g__90
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__93
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 RCB1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__92
  {
    struct __PST__g__93 BIT;
    __PST__UINT32 __pst_unused_field_1;
  };
typedef __PST__SINT8 __PST__g__236[4];
struct __PST__g__108
  {
    __PST__UINT16 BRS : 12;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 4;
  };
union __PST__g__107
  {
    struct __PST__g__108 BIT;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__42
  {
    union __PST__g__43 CTL0;
    __PST__g__232 __pst_unused_field_1;
    __PST__g__48 STR0;
    union __PST__g__55 STCR0;
    __PST__g__233 __pst_unused_field_4;
    union __PST__g__59 CTL1;
    union __PST__g__62 CTL2;
    __PST__g__234 __pst_unused_field_7;
    union __PST__g__65 MCTL1;
    union __PST__g__69 MCTL2;
    union __PST__g__71 TX0W;
    __PST__g__110 __pst_unused_field_11;
    __PST__g__110 __pst_unused_field_12;
    union __PST__g__76 RX0W;
    __PST__g__110 __pst_unused_field_14;
    __PST__g__110 __pst_unused_field_15;
    union __PST__g__84 MRWP0;
    __PST__g__235 __pst_unused_field_17;
    union __PST__g__87 MCTL0;
    __PST__g__110 __pst_unused_field_19;
    union __PST__g__90 CFG0;
    union __PST__g__92 CFG1;
    __PST__g__236 __pst_unused_field_22;
    __PST__g__236 __pst_unused_field_23;
    __PST__g__236 __pst_unused_field_24;
    __PST__g__236 __pst_unused_field_25;
    __PST__g__236 __pst_unused_field_26;
    __PST__g__236 __pst_unused_field_27;
    __PST__g__236 __pst_unused_field_28;
    union __PST__g__107 BRS0;
    __PST__g__110 __pst_unused_field_30;
    __PST__g__110 __pst_unused_field_31;
    __PST__g__110 __pst_unused_field_32;
    __PST__g__110 __pst_unused_field_33;
    __PST__g__110 __pst_unused_field_34;
    __PST__g__110 __pst_unused_field_35;
    __PST__g__110 __pst_unused_field___pstfiller;
  };
typedef volatile struct __PST__g__42 __PST__g__41;
typedef __PST__UINT8 __PST__g__47[3];
struct __PST__g__51
  {
    const __PST__UINT32 __pst_unused_field_0 : 1;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef3 : 5;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    const __PST__UINT32 __pst_unused_field_11 : 1;
    const __PST__UINT32 __pst_unused_field_12 : 8;
    const __PST__UINT32 __pst_unused_field_13 : 8;
  };
typedef const struct __PST__g__51 __PST__g__50;
typedef const __PST__UINT8 __PST__g__54;
struct __PST__g__56
  {
    __PST__UINT16 __pst_unused_field_0 : 1;
    __PST__UINT16 __pst_unused_field_1 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 1;
    __PST__UINT16 __pst_unused_field_3 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 4;
    __PST__UINT16 __pst_unused_field_5 : 1;
    __PST__UINT16 __pst_unused_field_pstnonamef3 : 5;
    __PST__UINT16 __pst_unused_field_7 : 1;
    __PST__UINT16 __pst_unused_field_8 : 1;
  };
typedef __PST__UINT8 __PST__g__58[6];
struct __PST__g__60
  {
    __PST__UINT32 __pst_unused_field_0 : 1;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_9 : 1;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
    __PST__UINT32 __pst_unused_field_13 : 1;
    __PST__UINT32 __pst_unused_field_14 : 1;
    __PST__UINT32 __pst_unused_field_15 : 1;
    __PST__UINT32 __pst_unused_field_16 : 1;
    __PST__UINT32 __pst_unused_field_17 : 1;
    __PST__UINT32 __pst_unused_field_18 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 13;
  };
struct __PST__g__63
  {
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 13;
    __PST__UINT16 __pst_unused_field_1 : 3;
  };
typedef __PST__UINT8 __PST__g__64[4074];
struct __PST__g__66
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 9;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 9;
  };
struct __PST__g__70
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 9;
    __PST__UINT32 __pst_unused_field_2 : 8;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 7;
    __PST__UINT32 __pst_unused_field_4 : 1;
  };
struct __PST__g__72
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    __PST__UINT32 __pst_unused_field_1 : 1;
    __PST__UINT32 __pst_unused_field_2 : 1;
    __PST__UINT32 __pst_unused_field_3 : 1;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 5;
    __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_11 : 1;
    __PST__UINT32 __pst_unused_field_12 : 1;
  };
union __PST__g__73
  {
    __PST__g__238 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
struct __PST__g__74
  {
    __PST__UINT16 __pst_unused_field_0 : 16;
  };
typedef __PST__UINT8 __PST__g__75[2];
struct __PST__g__77
  {
    __PST__UINT32 __pst_unused_field_0 : 16;
    const __PST__UINT32 __pst_unused_field_1 : 1;
    const __PST__UINT32 __pst_unused_field_2 : 1;
    const __PST__UINT32 __pst_unused_field_3 : 1;
    const __PST__UINT32 __pst_unused_field_4 : 1;
    const __PST__UINT32 __pst_unused_field_5 : 1;
    const __PST__UINT32 __pst_unused_field_6 : 1;
    const __PST__UINT32 __pst_unused_field_7 : 1;
    const __PST__UINT32 __pst_unused_field_8 : 1;
    const __PST__UINT32 __pst_unused_field_9 : 1;
    const __PST__UINT32 __pst_unused_field_10 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 6;
  };
union __PST__g__80
  {
    __PST__g__238 __pst_unused_field_0;
    __PST__UINT16 __pst_unused_field_1;
  };
typedef const union __PST__g__80 __PST__g__79;
struct __PST__g__82
  {
    const __PST__UINT16 __pst_unused_field_0 : 16;
  };
typedef const struct __PST__g__82 __PST__g__81;
typedef const __PST__UINT16 __PST__g__83;
struct __PST__g__85
  {
    __PST__UINT32 __pst_unused_field_0 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 9;
    __PST__UINT32 __pst_unused_field_2 : 7;
    __PST__UINT32 __pst_unused_field_pstnonamef2 : 9;
  };
typedef __PST__UINT8 __PST__g__86[36];
struct __PST__g__88
  {
    __PST__UINT16 __pst_unused_field_0 : 5;
    __PST__UINT16 __pst_unused_field_pstnonamef1 : 3;
    __PST__UINT16 __pst_unused_field_2 : 2;
    __PST__UINT16 __pst_unused_field_pstnonamef2 : 6;
  };
struct __PST__g__91
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__94
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__95
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__96
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__97
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__98
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__99
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__100
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__101
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__102
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__103
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
union __PST__g__104
  {
    __PST__g__237 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__105
  {
    __PST__UINT32 __pst_unused_field_0 : 4;
    __PST__UINT32 __pst_unused_field_1 : 4;
    __PST__UINT32 __pst_unused_field_2 : 4;
    __PST__UINT32 __pst_unused_field_3 : 3;
    __PST__UINT32 __pst_unused_field_4 : 1;
    __PST__UINT32 __pst_unused_field_5 : 1;
    __PST__UINT32 __pst_unused_field_6 : 1;
    __PST__UINT32 __pst_unused_field_7 : 1;
    __PST__UINT32 __pst_unused_field_8 : 1;
    __PST__UINT32 __pst_unused_field_pstnonamef1 : 4;
    __PST__UINT32 __pst_unused_field_10 : 4;
    __PST__UINT32 __pst_unused_field_11 : 2;
    __PST__UINT32 __pst_unused_field_12 : 2;
  };
typedef __PST__UINT8 __PST__g__106[4];
typedef __PST__VOID __PST__g__111(__PST__SINT32);
typedef __PST__UINT8 __PST__g__112(__PST__g__26);
typedef __PST__UINT8 __PST__g__113(__PST__UINT8);
typedef __PST__UINT8 __PST__g__114(__PST__SINT32);
typedef __PST__UINT8 __PST__g__115(__PST__g__35);
typedef __PST__UINT8 __PST__g__116(__PST__UINT16, __PST__g__36);
typedef __PST__UINT8 __PST__g__117(__PST__g__38);
typedef __PST__UINT8 __PST__g__118(__PST__UINT32, __PST__g__38);
typedef __PST__UINT8 __PST__g__119(void);
typedef __PST__UINT8 __PST__g__120(__PST__g__36);
typedef __PST__UINT8 __PST__g__121(__PST__UINT16, __PST__UINT8, __PST__UINT8, __PST__UINT16);
typedef __PST__UINT16 __PST__g__122(void);
typedef __PST__VOID __PST__g__123(__PST__UINT16);
typedef __PST__VOID __PST__g__124(__PST__UINT8);
typedef __PST__FLOAT32 __PST__g__125(__PST__FLOAT32);
typedef __PST__VOID __PST__g__126(__PST__g__38);
typedef __PST__VOID __PST__g__127(__PST__g__35);
typedef const __PST__UINT32 __PST__g__128;
typedef __PST__UINT32 __PST__g__129(__PST__SINT32);
typedef __PST__g__125 *__PST__g__130;
typedef __PST__VOID __PST__g__131(__PST__FLOAT32, __PST__g__16, __PST__g__16);
typedef __PST__SINT16 __PST__g__132(__PST__FLOAT32, __PST__FLOAT32);
typedef __PST__FLOAT32 __PST__g__133(__PST__SINT32, __PST__FLOAT32);
typedef const __PST__g__31 __PST__g__134;
typedef __PST__g__134 *__PST__g__135;
typedef __PST__g__111 *__PST__g__136;
typedef __PST__g__113 *__PST__g__137;
typedef __PST__g__41 *__PST__g__138;
typedef volatile union __PST__g__43 __PST__g__139;
typedef __PST__g__139 *__PST__g__140;
typedef volatile __PST__UINT8 __PST__g__141;
typedef __PST__g__141 *__PST__g__142;
typedef volatile union __PST__g__55 __PST__g__143;
typedef __PST__g__143 *__PST__g__144;
typedef volatile __PST__UINT16 __PST__g__145;
typedef __PST__g__145 *__PST__g__146;
typedef volatile union __PST__g__59 __PST__g__147;
typedef __PST__g__147 *__PST__g__148;
typedef volatile __PST__UINT32 __PST__g__149;
typedef __PST__g__149 *__PST__g__150;
typedef volatile union __PST__g__62 __PST__g__151;
typedef __PST__g__151 *__PST__g__152;
typedef volatile union __PST__g__87 __PST__g__153;
typedef __PST__g__153 *__PST__g__154;
typedef volatile union __PST__g__65 __PST__g__155;
typedef __PST__g__155 *__PST__g__156;
typedef volatile union __PST__g__90 __PST__g__157;
typedef __PST__g__157 *__PST__g__158;
typedef volatile union __PST__g__92 __PST__g__159;
typedef __PST__g__159 *__PST__g__160;
typedef volatile struct __PST__g__93 __PST__g__161;
typedef __PST__g__161 *__PST__g__162;
typedef volatile union __PST__g__107 __PST__g__165;
typedef __PST__g__165 *__PST__g__166;
typedef volatile struct __PST__g__108 __PST__g__167;
typedef __PST__g__167 *__PST__g__168;
typedef volatile union __PST__g__84 __PST__g__171;
typedef __PST__g__171 *__PST__g__172;
typedef volatile union __PST__g__71 __PST__g__173;
typedef __PST__g__173 *__PST__g__174;
typedef volatile struct __PST__g__44 __PST__g__175;
typedef __PST__g__175 *__PST__g__176;
typedef volatile union __PST__g__69 __PST__g__177;
typedef __PST__g__177 *__PST__g__178;
typedef __PST__g__120 *__PST__g__179;
typedef __PST__g__20 *__PST__g__180;
typedef __PST__g__112 *__PST__g__181;
typedef __PST__g__122 *__PST__g__182;
typedef __PST__g__119 *__PST__g__183;
typedef volatile union __PST__g__76 __PST__g__184;
typedef __PST__g__184 *__PST__g__185;
typedef const __PST__g__39 __PST__g__186;
typedef __PST__g__186 *__PST__g__187;
typedef const __PST__g__35 __PST__g__188;
typedef __PST__g__188 *__PST__g__189;
typedef const __PST__g__38 __PST__g__190;
typedef __PST__g__190 *__PST__g__191;
typedef const __PST__g__36 __PST__g__192;
typedef __PST__g__192 *__PST__g__193;
typedef const __PST__g__37 __PST__g__194;
typedef __PST__g__194 *__PST__g__195;
typedef __PST__g__129 *__PST__g__196;
typedef const __PST__g__16 __PST__g__197;
typedef __PST__g__197 *__PST__g__198;
typedef __PST__g__133 *__PST__g__199;
typedef __PST__UINT8 __PST__g__200(__PST__UINT32, __PST__UINT8);
typedef __PST__g__200 *__PST__g__201;
typedef __PST__g__121 *__PST__g__202;
typedef __PST__g__116 *__PST__g__203;
typedef __PST__g__114 *__PST__g__204;
typedef __PST__g__117 *__PST__g__205;
typedef __PST__g__118 *__PST__g__206;
typedef __PST__g__115 *__PST__g__207;
typedef __PST__g__123 *__PST__g__208;
typedef __PST__g__124 *__PST__g__209;
typedef volatile __PST__g__48 __PST__g__210;
typedef __PST__g__210 *__PST__g__211;
typedef volatile __PST__g__128 __PST__g__212;
typedef __PST__g__212 *__PST__g__213;
typedef __PST__FLOAT32 __PST__g__214[128];
typedef __PST__g__131 *__PST__g__215;
typedef __PST__g__214 *__PST__g__216;
typedef const __PST__g__33 __PST__g__217;
typedef __PST__g__217 *__PST__g__218;
typedef __PST__g__132 *__PST__g__219;
typedef __PST__g__126 *__PST__g__220;
typedef __PST__g__127 *__PST__g__221;
typedef volatile __PST__SINT32 __PST__g__222;
typedef __PST__SINT8 __PST__g__228(void);
typedef volatile __PST__SINT8 __PST__g__229;
typedef __PST__SINT32 __PST__g__230(void);
typedef __PST__UINT32 __PST__g__231(void);
