/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_CDD_MotAg0Meas_MotAgMecl0Polarity_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_CDD_MotAg0Meas_MotAgMecl0Polarity_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_CDD_MotAg0Meas_MotAgMecl0Polarity_Val"
// #pragma POLYSPACE_WORST "Rte_Read_CDD_MotAg0Meas_MotAgMecl0Polarity_Val"
//
// __PST__UINT8 Rte_Read_CDD_MotAg0Meas_MotAgMecl0Polarity_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotAg0Meas_MotAg0MeclQlfr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotAg0Meas_MotAg0MeclQlfr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotAg0Meas_MotAg0MeclQlfr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotAg0Meas_MotAg0MeclQlfr_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotAg0Meas_MotAg0MeclQlfr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotAg0Meas_MotAg0MeclRollgCntr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotAg0Meas_MotAg0MeclRollgCntr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotAg0Meas_MotAg0MeclRollgCntr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotAg0Meas_MotAg0MeclRollgCntr_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotAg0Meas_MotAg0MeclRollgCntr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_CDD_MotAg0Meas_MotAg0Offs_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_CDD_MotAg0Meas_MotAg0Offs_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_CDD_MotAg0Meas_MotAg0Offs_Val"
// #pragma POLYSPACE_WORST "Rte_Write_CDD_MotAg0Meas_MotAg0Offs_Val"
//
// __PST__UINT8 Rte_Write_CDD_MotAg0Meas_MotAg0Offs_Val(__PST__SINT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_GetMotAg3Mecl_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_GetMotAg3Mecl_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_GetMotAg3Mecl_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_GetMotAg3Mecl_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_GetMotAg3Mecl_Oper(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_GetNtcQlfrSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_GetNtcQlfrSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_GetNtcQlfrSts_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_GetNtcQlfrSts_Oper(__PST__UINT16 P_0, __PST__g__36 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_GetRefTmr1MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_GetRefTmr1MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_GetRefTmr1MicroSec32bit_Oper(__PST__g__38 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_GetTiSpan1MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_GetTiSpan1MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_GetTiSpan1MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_GetTiSpan1MicroSec32bit_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_GetTiSpan1MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__38 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctGpioMotAg0_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctGpioMotAg0_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctGpioMotAg0_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctGpioMotAg0_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctGpioMotAg0_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctPrphlCsihMotAg0_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctPrphlCsihMotAg0_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctPrphlCsihMotAg0_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctPrphlCsihMotAg0_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_IoHwAb_SetFctPrphlCsihMotAg0_Oper(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_IoHwAb_SetGpioMotAg0CsihCs_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetGpioMotAg0CsihCs_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetGpioMotAg0CsihCs_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_IoHwAb_SetGpioMotAg0CsihCs_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_IoHwAb_SetGpioMotAg0CsihCs_Oper(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_GetErrorStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_GetErrorStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_GetErrorStatus"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_GetErrorStatus"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_GetErrorStatus(__PST__g__36 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_SetRamBlockStatus"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_MotAg0CoeffTbl_SetRamBlockStatus(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_CDD_MotAg0Meas_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_CDD_MotAg0Meas_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_CDD_MotAg0Meas_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_CDD_MotAg0Meas_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_CDD_MotAg0Meas_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0DiagcAg
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0DiagcAg"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0DiagcAg"
// #pragma POLYSPACE_WORST "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0DiagcAg"
//
// __PST__UINT16 Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0DiagcAg(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0SpiTrsmEna
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0SpiTrsmEna"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0SpiTrsmEna"
// #pragma POLYSPACE_WORST "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0SpiTrsmEna"
//
// __PST__UINT8 Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg0SpiTrsmEna(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg3Mecl
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg3Mecl"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg3Mecl"
// #pragma POLYSPACE_WORST "Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg3Mecl"
//
// __PST__UINT16 Rte_IrvRead_CDD_MotAg0Meas_MotAg0MeasPer2_MotAg3Mecl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0DiagcAg
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0DiagcAg"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0DiagcAg"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0DiagcAg"
//
// __PST__VOID Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0DiagcAg(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0SpiTrsmEna
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0SpiTrsmEna"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0SpiTrsmEna"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0SpiTrsmEna"
//
// __PST__VOID Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg0SpiTrsmEna(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg3Mecl
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg3Mecl"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg3Mecl"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg3Mecl"
//
// __PST__VOID Rte_IrvWrite_CDD_MotAg0Meas_MotAg0MeasPer3_MotAg3Mecl(__PST__UINT16 P_0)
// {
//    ...
// }


// Pragmas for function fabsf
//
// #pragma POLYSPACE_PURE "fabsf"
// #pragma POLYSPACE_CLEAN "fabsf"
// #pragma POLYSPACE_WORST "fabsf"
//
// __PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function GetRefTmr1MicroSec32bit_Oper
//
// #pragma POLYSPACE_PURE "GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_CLEAN "GetRefTmr1MicroSec32bit_Oper"
// #pragma POLYSPACE_WORST "GetRefTmr1MicroSec32bit_Oper"
//
// __PST__VOID GetRefTmr1MicroSec32bit_Oper(__PST__g__38 P_0)
// {
//    ...
// }


// Pragmas for function GetMotAg3Mecl_Oper
//
// #pragma POLYSPACE_PURE "GetMotAg3Mecl_Oper"
// #pragma POLYSPACE_CLEAN "GetMotAg3Mecl_Oper"
// #pragma POLYSPACE_WORST "GetMotAg3Mecl_Oper"
//
// __PST__VOID GetMotAg3Mecl_Oper(__PST__g__35 P_0)
// {
//    ...
// }

