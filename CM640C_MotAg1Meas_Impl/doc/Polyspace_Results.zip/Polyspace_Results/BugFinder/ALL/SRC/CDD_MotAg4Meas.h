/* header file for contract folder of CM640C */

extern void GetMotAg4Mecl_Oper(u0p16 *MotAg1RawMecl);
