/* header file for contract folder of CM640C */

#ifndef CDD_MOTCTRLMGR_DATA_H
#define CDD_MOTCTRLMGR_DATA_H

extern uint32 MOTCTRLMGR_MotCtrlMotAgMeasTi;
extern uint16 MOTCTRLMGR_MotCtrlMotAg1Mecl;             /* Actual type is u0p16 */
extern sint32 MOTCTRLMGR_MotCtrlMotAg1Offs;

#endif

