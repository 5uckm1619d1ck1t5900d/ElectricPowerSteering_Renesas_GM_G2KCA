#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT32 pst_random_g_4;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__107 _main_gen_init_g107(void);

extern struct __PST__g__93 _main_gen_init_g93(void);

extern union __PST__g__92 _main_gen_init_g92(void);

extern union __PST__g__90 _main_gen_init_g90(void);

extern union __PST__g__87 _main_gen_init_g87(void);

extern union __PST__g__84 _main_gen_init_g84(void);

extern union __PST__g__76 _main_gen_init_g76(void);

extern union __PST__g__71 _main_gen_init_g71(void);

extern union __PST__g__69 _main_gen_init_g69(void);

extern union __PST__g__65 _main_gen_init_g65(void);

extern union __PST__g__62 _main_gen_init_g62(void);

extern union __PST__g__59 _main_gen_init_g59(void);

extern union __PST__g__55 _main_gen_init_g55(void);

extern union __PST__g__49 _main_gen_init_g49(void);

extern struct __PST__g__44 _main_gen_init_g44(void);

extern union __PST__g__43 _main_gen_init_g43(void);

extern __PST__g__41 _main_gen_init_g41(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern struct Rte_CDS_CDD_MotAg1Meas _main_gen_init_g30(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_MotAg1Meas _main_gen_init_g30(void)
{
    static struct Rte_CDS_CDD_MotAg1Meas x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__g__32); _i_main_gen_tmp_7++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_8_0;
                
                for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 26; _main_gen_tmp_8_0++)
                {
                    /* base type */
                    _main_gen_tmp_6[_i_main_gen_tmp_7][_main_gen_tmp_8_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_MotAg1CoeffTbl = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__g__32) / 2];
    }
    /* pointer */
    {
        static __PST__g__34 _main_gen_tmp_9[ARRAY_NBELEM(__PST__g__34)];
        __PST__UINT32 _i_main_gen_tmp_10;
        for (_i_main_gen_tmp_10 = 0; _i_main_gen_tmp_10 < ARRAY_NBELEM(__PST__g__34); _i_main_gen_tmp_10++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_11_0;
                
                for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 128; _main_gen_tmp_11_0++)
                {
                    /* base type */
                    _main_gen_tmp_9[_i_main_gen_tmp_10][_main_gen_tmp_11_0] = pst_random_g_2;
                }
            }
        }
        x.Pim_MotAg1CorrnTbl = PST_TRUE() ? 0 : &_main_gen_tmp_9[ARRAY_NBELEM(__PST__g__34) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g7();
        }
        x.Pim_MotAg1Diagc = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g6();
        }
        x.Pim_MotAg1InitOffs = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__SINT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__SINT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g4();
        }
        x.Pim_MotAg1PrevOffs = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__SINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g6();
        }
        x.Pim_MotAg1PrevRollgCntr = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g7();
        }
        x.Pim_MotAg1PrevSpiErrFltCntr = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g7();
        }
        x.Pim_dMotAg1MeasMotAg1Delta = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawAgReg = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawErrReg = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__40 _main_gen_tmp_28[ARRAY_NBELEM(__PST__g__40)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__g__40); _i_main_gen_tmp_29++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_30_0;
                
                for (_main_gen_tmp_30_0 = 0; _main_gen_tmp_30_0 < 10; _main_gen_tmp_30_0++)
                {
                    /* base type */
                    _main_gen_tmp_28[_i_main_gen_tmp_29][_main_gen_tmp_30_0] = pst_random_g_8;
                }
            }
        }
        x.Pim_dMotAg1MeasMotAg1RawReg = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__g__40) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_31[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_32;
        for (_i_main_gen_tmp_32 = 0; _i_main_gen_tmp_32 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_32++)
        {
            _main_gen_tmp_31[_i_main_gen_tmp_32] = _main_gen_init_g8();
        }
        x.Pim_dMotAg1MeasMotAg1RawTurnCntrReg = PST_TRUE() ? 0 : &_main_gen_tmp_31[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__SINT32 _main_gen_tmp_33[ARRAY_NBELEM(__PST__SINT32)];
        __PST__UINT32 _i_main_gen_tmp_34;
        for (_i_main_gen_tmp_34 = 0; _i_main_gen_tmp_34 < ARRAY_NBELEM(__PST__SINT32); _i_main_gen_tmp_34++)
        {
            _main_gen_tmp_33[_i_main_gen_tmp_34] = _main_gen_init_g4();
        }
        x.Pim_dMotAg1MeasMotAg1RtOffs = PST_TRUE() ? 0 : &_main_gen_tmp_33[ARRAY_NBELEM(__PST__SINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_35[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_36;
        for (_i_main_gen_tmp_36 = 0; _i_main_gen_tmp_36 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_36++)
        {
            _main_gen_tmp_35[_i_main_gen_tmp_36] = _main_gen_init_g7();
        }
        x.Pim_dMotAg1MeasMotAg1SpiCntrAg = PST_TRUE() ? 0 : &_main_gen_tmp_35[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_37[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_38;
        for (_i_main_gen_tmp_38 = 0; _i_main_gen_tmp_38 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_38++)
        {
            _main_gen_tmp_37[_i_main_gen_tmp_38] = _main_gen_init_g7();
        }
        x.Pim_dMotAg1MeasMotAg1SpiMecl = PST_TRUE() ? 0 : &_main_gen_tmp_37[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_39[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_40;
        for (_i_main_gen_tmp_40 = 0; _i_main_gen_tmp_40 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_40++)
        {
            _main_gen_tmp_39[_i_main_gen_tmp_40] = _main_gen_init_g10();
        }
        x.Pim_dMotAg1MeasMotAg1TurnCntr = PST_TRUE() ? 0 : &_main_gen_tmp_39[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_41[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_42;
        for (_i_main_gen_tmp_42 = 0; _i_main_gen_tmp_42 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_42++)
        {
            _main_gen_tmp_41[_i_main_gen_tmp_42] = _main_gen_init_g7();
        }
        x.Pim_dMotAg1MeasMotCtrlMotAg4Mecl = PST_TRUE() ? 0 : &_main_gen_tmp_41[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    return x;
}

struct __PST__g__44 _main_gen_init_g44(void)
{
    static struct __PST__g__44 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PWR = bitf;
    }
    return x;
}

union __PST__g__43 _main_gen_init_g43(void)
{
    static union __PST__g__43 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g44();
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__49 _main_gen_init_g49(void)
{
    static union __PST__g__49 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__55 _main_gen_init_g55(void)
{
    static union __PST__g__55 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__59 _main_gen_init_g59(void)
{
    static union __PST__g__59 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__62 _main_gen_init_g62(void)
{
    static union __PST__g__62 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__65 _main_gen_init_g65(void)
{
    static union __PST__g__65 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__69 _main_gen_init_g69(void)
{
    static union __PST__g__69 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__71 _main_gen_init_g71(void)
{
    static union __PST__g__71 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__76 _main_gen_init_g76(void)
{
    static union __PST__g__76 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__84 _main_gen_init_g84(void)
{
    static union __PST__g__84 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__87 _main_gen_init_g87(void)
{
    static union __PST__g__87 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__90 _main_gen_init_g90(void)
{
    static union __PST__g__90 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__93 _main_gen_init_g93(void)
{
    static struct __PST__g__93 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.RCB1 = bitf;
    }
    return x;
}

union __PST__g__92 _main_gen_init_g92(void)
{
    static union __PST__g__92 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g93();
    return x;
}

struct __PST__g__108 _main_gen_init_g108(void)
{
    static struct __PST__g__108 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 4095);
        x.BRS = bitf;
    }
    return x;
}

union __PST__g__107 _main_gen_init_g107(void)
{
    static union __PST__g__107 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g108();
    return x;
}

__PST__g__41 _main_gen_init_g41(void)
{
    __PST__g__41 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g43();
    x.STR0 = _main_gen_init_g49();
    x.STCR0 = _main_gen_init_g55();
    x.CTL1 = _main_gen_init_g59();
    x.CTL2 = _main_gen_init_g62();
    x.MCTL1 = _main_gen_init_g65();
    x.MCTL2 = _main_gen_init_g69();
    x.TX0W = _main_gen_init_g71();
    x.RX0W = _main_gen_init_g76();
    x.MRWP0 = _main_gen_init_g84();
    x.MCTL0 = _main_gen_init_g87();
    x.CFG0 = _main_gen_init_g90();
    x.CFG1 = _main_gen_init_g92();
    x.BRS0 = _main_gen_init_g107();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_MotAg1Meas(void)
{
    extern __PST__g__27 Rte_Inst_CDD_MotAg1Meas;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_MotAg1Meas _main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas)];
            __PST__UINT32 _i_main_gen_tmp_5;
            for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas); _i_main_gen_tmp_5++)
            {
                _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g30();
            }
            Rte_Inst_CDD_MotAg1Meas = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAg1Meas) / 2];
        }
    }
}

static void _main_gen_init_sym_CSIH3(void)
{
    extern __PST__g__41 CSIH3;
    
    /* initialization with random value */
    {
        CSIH3 = _main_gen_init_g41();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi(void)
{
    extern __PST__UINT32 MOTCTRLMGR_MotCtrlMotAgMeasTi;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMeasTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1Offs(void)
{
    extern __PST__SINT32 MOTCTRLMGR_MotCtrlMotAg1Offs;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAg1Offs = _main_gen_init_g4();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_MotAg1Meas */
    _main_gen_init_sym_Rte_Inst_CDD_MotAg1Meas();
    
    /* init for variable CSIH3 */
    _main_gen_init_sym_CSIH3();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMeasTi */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMeasTi();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAg1Mecl : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAg1Offs */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAg1Offs();
    
}
