/* header file for contract folder of CM745A */

#ifndef OS_H
#define OS_H

#define Call_IninSciDtsChMstReg IninSciDtsChMstReg

#endif

