/*****************************************************************************
* Copyright 2017 Nexteer 
* Nexteer Confidential
*
* Module File Name  : CDD_Sci30CfgAndUse.h
* Module Description: Header file for Sci30CfgAndUse
* Project           : CBD
* Author            : Avinash James
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       nz63rn %
*----------------------------------------------------------------------------------------------------------------------
* Date      Rev      Author         Change Description                                                           SCR #
* -------   -------  --------  ---------------------------------------------------------------------------     --------
* 01/13/17      1        AJM                    Initial version                                                            EA4#8022
**********************************************************************************************************************/

#ifndef CDD_SCI30CFGANDUSE_H
#define CDD_SCI30CFGANDUSE_H

extern FUNC(void, CDD_Sci30CfgAnduse_CODE)IninSciDtsChMstReg(void);

#endif
