#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__188 _main_gen_init_g188(void);

extern union __PST__g__181 _main_gen_init_g181(void);

extern union __PST__g__186 _main_gen_init_g186(void);

extern union __PST__g__159 _main_gen_init_g159(void);

extern union __PST__g__157 _main_gen_init_g157(void);

extern union __PST__g__155 _main_gen_init_g155(void);

extern union __PST__g__184 _main_gen_init_g184(void);

extern union __PST__g__150 _main_gen_init_g150(void);

extern union __PST__g__148 _main_gen_init_g148(void);

extern union __PST__g__146 _main_gen_init_g146(void);

extern union __PST__g__144 _main_gen_init_g144(void);

extern __PST__g__54 _main_gen_init_g54(void);

extern union __PST__g__51 _main_gen_init_g51(void);

extern union __PST__g__48 _main_gen_init_g48(void);

extern struct __PST__g__45 _main_gen_init_g45(void);

extern union __PST__g__44 _main_gen_init_g44(void);

extern union __PST__g__42 _main_gen_init_g42(void);

extern union __PST__g__37 _main_gen_init_g37(void);

extern __PST__g__35 _main_gen_init_g35(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_Sci30CfgAndUse _main_gen_init_g25(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_CDD_Sci30CfgAndUse _main_gen_init_g25(void)
{
    static struct Rte_CDS_CDD_Sci30CfgAndUse x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__g__27 _main_gen_tmp_2[ARRAY_NBELEM(__PST__g__27)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__g__27); _i_main_gen_tmp_3++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_4_0;
                
                for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 3; _main_gen_tmp_4_0++)
                {
                    __PST__UINT32 _main_gen_tmp_4_1;
                    
                    for (_main_gen_tmp_4_1 = 0; _main_gen_tmp_4_1 < 8; _main_gen_tmp_4_1++)
                    {
                        /* base type */
                        _main_gen_tmp_2[_i_main_gen_tmp_3][_main_gen_tmp_4_0][_main_gen_tmp_4_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_Sci100MilliSecBufCnt = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__g__27) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_5[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_6;
        for (_i_main_gen_tmp_6 = 0; _i_main_gen_tmp_6 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_6++)
        {
            _main_gen_tmp_5[_i_main_gen_tmp_6] = _main_gen_init_g6();
        }
        x.Pim_Sci100MilliSecReadCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_5[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__g__31 _main_gen_tmp_7[ARRAY_NBELEM(__PST__g__31)];
        __PST__UINT32 _i_main_gen_tmp_8;
        for (_i_main_gen_tmp_8 = 0; _i_main_gen_tmp_8 < ARRAY_NBELEM(__PST__g__31); _i_main_gen_tmp_8++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_9_0;
                
                for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 2; _main_gen_tmp_9_0++)
                {
                    __PST__UINT32 _main_gen_tmp_9_1;
                    
                    for (_main_gen_tmp_9_1 = 0; _main_gen_tmp_9_1 < 8; _main_gen_tmp_9_1++)
                    {
                        /* base type */
                        _main_gen_tmp_7[_i_main_gen_tmp_8][_main_gen_tmp_9_0][_main_gen_tmp_9_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_Sci10MilliSecBufCnt = PST_TRUE() ? 0 : &_main_gen_tmp_7[ARRAY_NBELEM(__PST__g__31) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        x.Pim_Sci10MilliSecReadCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__g__33 _main_gen_tmp_12[ARRAY_NBELEM(__PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__g__33); _i_main_gen_tmp_13++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_14_0;
                
                for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 1; _main_gen_tmp_14_0++)
                {
                    __PST__UINT32 _main_gen_tmp_14_1;
                    
                    for (_main_gen_tmp_14_1 = 0; _main_gen_tmp_14_1 < 8; _main_gen_tmp_14_1++)
                    {
                        /* base type */
                        _main_gen_tmp_12[_i_main_gen_tmp_13][_main_gen_tmp_14_0][_main_gen_tmp_14_1] = pst_random_g_6;
                    }
                }
            }
        }
        x.Pim_Sci2MilliSecBufCnt = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_15[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_16;
        for (_i_main_gen_tmp_16 = 0; _i_main_gen_tmp_16 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_16++)
        {
            _main_gen_tmp_15[_i_main_gen_tmp_16] = _main_gen_init_g8();
        }
        x.Pim_SciDiagcFrmErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_15[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_17[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_18;
        for (_i_main_gen_tmp_18 = 0; _i_main_gen_tmp_18 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_18++)
        {
            _main_gen_tmp_17[_i_main_gen_tmp_18] = _main_gen_init_g8();
        }
        x.Pim_SciDiagcOvrrunErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_17[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_19[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_20;
        for (_i_main_gen_tmp_20 = 0; _i_main_gen_tmp_20 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_20++)
        {
            _main_gen_tmp_19[_i_main_gen_tmp_20] = _main_gen_init_g8();
        }
        x.Pim_SciDiagcParErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_19[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_21[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_22;
        for (_i_main_gen_tmp_22 = 0; _i_main_gen_tmp_22 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_22++)
        {
            _main_gen_tmp_21[_i_main_gen_tmp_22] = _main_gen_init_g8();
        }
        x.Pim_SciDiagcRxMaxDataErrCntr = PST_TRUE() ? 0 : &_main_gen_tmp_21[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_23[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_24;
        for (_i_main_gen_tmp_24 = 0; _i_main_gen_tmp_24 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_24++)
        {
            _main_gen_tmp_23[_i_main_gen_tmp_24] = _main_gen_init_g6();
        }
        x.Pim_SciNrOfPnd100MilliSecFrmCnt = PST_TRUE() ? 0 : &_main_gen_tmp_23[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_25[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_26;
        for (_i_main_gen_tmp_26 = 0; _i_main_gen_tmp_26 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_26++)
        {
            _main_gen_tmp_25[_i_main_gen_tmp_26] = _main_gen_init_g6();
        }
        x.Pim_SciNrOfPnd10MilliSecFrmCnt = PST_TRUE() ? 0 : &_main_gen_tmp_25[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_27[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_28;
        for (_i_main_gen_tmp_28 = 0; _i_main_gen_tmp_28 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_28++)
        {
            _main_gen_tmp_27[_i_main_gen_tmp_28] = _main_gen_init_g6();
        }
        x.Pim_SciRxPrevLoopDataUnread = PST_TRUE() ? 0 : &_main_gen_tmp_27[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_29[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_30;
        for (_i_main_gen_tmp_30 = 0; _i_main_gen_tmp_30 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_30++)
        {
            _main_gen_tmp_29[_i_main_gen_tmp_30] = _main_gen_init_g6();
        }
        x.Pim_SciRxProcIdx = PST_TRUE() ? 0 : &_main_gen_tmp_29[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}

union __PST__g__37 _main_gen_init_g37(void)
{
    static union __PST__g__37 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__42 _main_gen_init_g42(void)
{
    static union __PST__g__42 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

struct __PST__g__45 _main_gen_init_g45(void)
{
    static struct __PST__g__45 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.PER = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.FER = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.ORER = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.RDRF = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.TDRE = bitf;
    }
    return x;
}

union __PST__g__44 _main_gen_init_g44(void)
{
    static union __PST__g__44 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g45();
    return x;
}

union __PST__g__48 _main_gen_init_g48(void)
{
    static union __PST__g__48 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__51 _main_gen_init_g51(void)
{
    static union __PST__g__51 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__35 _main_gen_init_g35(void)
{
    __PST__g__35 x;
    /* struct/union type */
    x.SMR = _main_gen_init_g37();
    x.SCR = _main_gen_init_g42();
    x.SSR = _main_gen_init_g44();
    x.SCMR = _main_gen_init_g48();
    x.SEMR = _main_gen_init_g51();
    x.BRR = _main_gen_init_g6();
    x.TDR = _main_gen_init_g6();
    x.RDR = _main_gen_init_g6();
    return x;
}

union __PST__g__144 _main_gen_init_g144(void)
{
    static union __PST__g__144 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__146 _main_gen_init_g146(void)
{
    static union __PST__g__146 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__148 _main_gen_init_g148(void)
{
    static union __PST__g__148 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__150 _main_gen_init_g150(void)
{
    static union __PST__g__150 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__184 _main_gen_init_g184(void)
{
    static union __PST__g__184 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__155 _main_gen_init_g155(void)
{
    static union __PST__g__155 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__157 _main_gen_init_g157(void)
{
    static union __PST__g__157 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__159 _main_gen_init_g159(void)
{
    static union __PST__g__159 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__186 _main_gen_init_g186(void)
{
    static union __PST__g__186 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__181 _main_gen_init_g181(void)
{
    static union __PST__g__181 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__188 _main_gen_init_g188(void)
{
    static union __PST__g__188 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__54 _main_gen_init_g54(void)
{
    __PST__g__54 x;
    /* struct/union type */
    x.DTS087CM = _main_gen_init_g144();
    x.DTS088CM = _main_gen_init_g144();
    x.DTSA087 = _main_gen_init_g146();
    x.DTDA087 = _main_gen_init_g148();
    x.DTTC087 = _main_gen_init_g150();
    x.DTTCT087 = _main_gen_init_g184();
    x.DTRSA087 = _main_gen_init_g155();
    x.DTRDA087 = _main_gen_init_g157();
    x.DTRTC087 = _main_gen_init_g159();
    x.DTFSL087 = _main_gen_init_g186();
    x.DTFSC087 = _main_gen_init_g181();
    x.DTSA088 = _main_gen_init_g146();
    x.DTDA088 = _main_gen_init_g148();
    x.DTTC088 = _main_gen_init_g150();
    x.DTTCT088 = _main_gen_init_g184();
    x.DTFSL088 = _main_gen_init_g186();
    x.DTFSS088 = _main_gen_init_g188();
    x.DTFSC088 = _main_gen_init_g181();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_Sci30CfgAndUse(void)
{
    extern __PST__g__22 Rte_Inst_CDD_Sci30CfgAndUse;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_Sci30CfgAndUse _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_Sci30CfgAndUse)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_CDD_Sci30CfgAndUse); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_CDD_Sci30CfgAndUse = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_CDD_Sci30CfgAndUse) / 2];
        }
    }
}

static void _main_gen_init_sym_SCI30(void)
{
    extern __PST__g__35 SCI30;
    
    /* initialization with random value */
    {
        SCI30 = _main_gen_init_g35();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__54 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g54();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_Sci30CfgAndUse */
    _main_gen_init_sym_Rte_Inst_CDD_Sci30CfgAndUse();
    
    /* init for variable SCI30 */
    _main_gen_init_sym_SCI30();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
}
