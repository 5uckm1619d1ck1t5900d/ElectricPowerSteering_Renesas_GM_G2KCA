#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_DualEcuIdn_EcuComTiOut_Logl
 */


__PST__UINT8 Rte_Read_DualEcuIdn_EcuComTiOut_Logl(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DualEcuIdn_EcuId_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DualEcuIdn_EcuId_Val"


__PST__UINT8 Rte_Write_DualEcuIdn_EcuId_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DualEcuIdn_GetSigImcData_u08_Oper
 */


__PST__UINT8 Rte_Call_DualEcuIdn_GetSigImcData_u08_Oper(__PST__UINT16 P_0, __PST__g__26 P_1, __PST__g__26 P_2)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_6;
        }
        P_1[0] = pst_random_g_6;
    }

    /* parameter 2 */

    if (P_2 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_2[pst_random_int] = pst_random_g_6;
        }
        P_2[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DualEcuIdn_IoHwAb_GetGpioEcuIdnPin1_Oper
 */


__PST__UINT8 Rte_Call_DualEcuIdn_IoHwAb_GetGpioEcuIdnPin1_Oper(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DualEcuIdn_IoHwAb_GetGpioEcuIdnPin2_Oper
 */


__PST__UINT8 Rte_Call_DualEcuIdn_IoHwAb_GetGpioEcuIdnPin2_Oper(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DualEcuIdn_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_DualEcuIdn_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_DualEcuIdn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

