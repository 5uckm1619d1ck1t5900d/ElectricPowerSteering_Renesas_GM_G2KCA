#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT8 pst_random_g_2;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__UINT8 _main_gen_init_g6(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_StHlthSigStc_GetCtrlrTStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetCtrlrTStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetCtrlrTStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetOutpAssiStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetOutpAssiStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetOutpAssiStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetAbsltMotPosABDifStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetAbsltMotPosABDifStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetAbsltMotPosABDifStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetAbsltMotPosBCDifStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetAbsltMotPosBCDifStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetAbsltMotPosBCDifStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetAbsltMotPosACDifStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetAbsltMotPosACDifStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetAbsltMotPosACDifStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetDigTqSnsrAStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetDigTqSnsrAStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetDigTqSnsrAStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetDutyCycStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetDutyCycStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetDutyCycStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetDigTqSnsrBStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetDigTqSnsrBStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetDigTqSnsrBStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaAStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaAStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaAStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetRamEccSngBitCorrnStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetRamEccSngBitCorrnStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetRamEccSngBitCorrnStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetMotPosStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetMotPosStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetMotPosStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetEotImpctStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetEotImpctStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetEotImpctStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaBStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaBStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaBStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaCStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaCStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaCStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaDStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaDStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaDStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaEStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaEStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaEStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetPhaFStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetPhaFStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetPhaFStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetDigTqIdptSigStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetDigTqIdptSigStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetDigTqIdptSigStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetCurrMotSumABCStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetCurrMotSumABCStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetCurrMotSumABCStHlthVal();
}

static void _main_gen_call_StHlthSigStc_GetCurrMotSumDEFStHlthVal(void)
{
    extern __PST__UINT8 StHlthSigStc_GetCurrMotSumDEFStHlthVal(__PST__VOID);

    __PST__UINT8 __ret__;
    
    
    /* call it */
    __ret__ = StHlthSigStc_GetCurrMotSumDEFStHlthVal();
}

static void _main_gen_call_ClrSigStcHlthData_Oper(void)
{
    extern __PST__VOID ClrSigStcHlthData_Oper(__PST__UINT8);

    __PST__UINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g6();
    
    /* call it */
    ClrSigStcHlthData_Oper(__arg__0);
}

static void _main_gen_call_GetSigStcHlthData_Oper(void)
{
    extern __PST__UINT8 GetSigStcHlthData_Oper(__PST__UINT8, __PST__g__17);

    __PST__UINT8 __ret__;
    __PST__UINT8 __arg__0;
    __PST__g__17 __arg__1;
    
    __arg__0 = _main_gen_init_g6();
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g8();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    __ret__ = GetSigStcHlthData_Oper(__arg__0, __arg__1);
}

static void _main_gen_call_UpdStHlthStcData_Oper(void)
{
    extern __PST__VOID UpdStHlthStcData_Oper(__PST__UINT8);

    __PST__UINT8 __arg__0;
    
    __arg__0 = _main_gen_init_g6();
    
    /* call it */
    UpdStHlthStcData_Oper(__arg__0);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_ClrDataSample(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_StHlthSigStc_ClrDataSample(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_StHlthSigStc_ClrDataSample(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_UpdNvmPim(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_StHlthSigStc_UpdNvmPim(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_StHlthSigStc_UpdNvmPim(__arg__0, __arg__1);
}

static void _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_UpdDataSample(void)
{
    extern __PST__VOID NONTRUSTED_NtWrapS_StHlthSigStc_UpdDataSample(__PST__UINT16, __PST__g__11);

    __PST__UINT16 __arg__0;
    __PST__g__11 __arg__1;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT8 _main_gen_tmp_6[ARRAY_NBELEM(__PST__SINT8)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__SINT8); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g2();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__SINT8) / 2];
    }
    
    /* call it */
    NONTRUSTED_NtWrapS_StHlthSigStc_UpdDataSample(__arg__0, __arg__1);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function StHlthSigStc_GetCtrlrTStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetCtrlrTStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetOutpAssiStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetOutpAssiStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetAbsltMotPosABDifStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetAbsltMotPosABDifStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetAbsltMotPosBCDifStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetAbsltMotPosBCDifStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetAbsltMotPosACDifStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetAbsltMotPosACDifStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetDigTqSnsrAStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetDigTqSnsrAStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetDutyCycStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetDutyCycStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetDigTqSnsrBStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetDigTqSnsrBStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaAStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaAStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetRamEccSngBitCorrnStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetRamEccSngBitCorrnStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetMotPosStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetMotPosStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetEotImpctStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetEotImpctStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaBStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaBStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaCStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaCStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaDStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaDStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaEStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaEStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetPhaFStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetPhaFStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetDigTqIdptSigStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetDigTqIdptSigStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetCurrMotSumABCStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetCurrMotSumABCStHlthVal();
        }
        
        /* call of function StHlthSigStc_GetCurrMotSumDEFStHlthVal */
        if (PST_TRUE())
        {
            _main_gen_call_StHlthSigStc_GetCurrMotSumDEFStHlthVal();
        }
        
        /* call of function ClrSigStcHlthData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ClrSigStcHlthData_Oper();
        }
        
        /* call of function GetSigStcHlthData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_GetSigStcHlthData_Oper();
        }
        
        /* call of function StHlthSigStcInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID StHlthSigStcInit1(__PST__VOID);

            StHlthSigStcInit1();
        }
        
        /* call of function StHlthStcPwrDwn_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID StHlthStcPwrDwn_Oper(__PST__VOID);

            StHlthStcPwrDwn_Oper();
        }
        
        /* call of function UpdStHlthStcData_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_UpdStHlthStcData_Oper();
        }
        
        /* call of function NONTRUSTED_NtWrapS_StHlthSigStc_ClrDataSample */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_ClrDataSample();
        }
        
        /* call of function NONTRUSTED_NtWrapS_StHlthSigStc_UpdNvmPim */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_UpdNvmPim();
        }
        
        /* call of function NONTRUSTED_NtWrapS_StHlthSigStc_UpdDataSample */
        if (PST_TRUE())
        {
            _main_gen_call_NONTRUSTED_NtWrapS_StHlthSigStc_UpdDataSample();
        }
        
    }
}
