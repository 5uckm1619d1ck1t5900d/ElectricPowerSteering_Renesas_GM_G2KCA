typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(__PST__UINT8);
typedef __PST__UINT32 *__PST__g__17;
typedef __PST__UINT8 __PST__g__16(__PST__UINT8, __PST__g__17);
typedef __PST__VOID __PST__g__18(void);
typedef __PST__VOID __PST__g__19(__PST__UINT16, __PST__g__11);
typedef __PST__UINT8 __PST__g__25(void);
typedef __PST__g__25 *__PST__g__24;
typedef __PST__SINT8 __PST__g__26[3];
struct __PST__g__23
  {
    __PST__g__24 GetStHlthDataOper;
    __PST__UINT16 SamplePerSec;
    __PST__UINT8 TaskRef;
    __PST__UINT8 RamStorgOffs;
    __PST__UINT8 NvmStorgOffs;
    __PST__g__26 __pst_unused_field___pstfiller;
  };
typedef const struct __PST__g__23 __PST__g__22;
typedef __PST__g__22 __PST__g__21[20];
typedef const __PST__UINT32 __PST__g__31;
typedef __PST__g__31 *__PST__g__30;
struct __PST__g__29
  {
    __PST__g__30 CrcStrtAdr;
  };
typedef const struct __PST__g__29 __PST__g__28;
typedef __PST__g__28 __PST__g__27[1];
typedef __PST__g__22 *__PST__g__34;
typedef __PST__g__28 *__PST__g__35;
struct __PST__g__33
  {
    __PST__g__34 SigPrm;
    __PST__g__35 CrcAdr;
  };
typedef const struct __PST__g__33 __PST__g__32;
typedef __PST__FLOAT64 __PST__g__36(void);
typedef __PST__g__11 *__PST__g__37;
typedef volatile __PST__FLOAT64 __PST__g__38;
typedef __PST__SINT8 *__PST__g__40;
typedef volatile __PST__g__40 __PST__g__39;
typedef const struct Rte_CDS_StHlthSigStc __PST__g__43;
typedef __PST__g__43 *__PST__g__42;
typedef const __PST__g__42 __PST__g__41;
typedef __PST__UINT32 __PST__g__46[20];
typedef __PST__g__46 *__PST__g__45;
typedef __PST__UINT8 __PST__g__48[80];
typedef __PST__g__48 *__PST__g__47;
typedef __PST__UINT8 __PST__g__50[225];
typedef __PST__g__50 *__PST__g__49;
typedef __PST__UINT8 *__PST__g__51;
struct Rte_CDS_StHlthSigStc
  {
    __PST__g__45 Pim_IgnCycSampleCntrAry;
    __PST__g__47 Pim_RamBuf;
    __PST__g__49 Pim_SigStcHistDataAry;
    __PST__g__51 Pim_VldNvm;
  };
typedef __PST__VOID __PST__g__52(__PST__SINT32);
typedef __PST__UINT8 __PST__g__53(__PST__g__51);
typedef __PST__UINT8 __PST__g__54(__PST__UINT8);
typedef __PST__UINT8 __PST__g__55(__PST__g__51, __PST__UINT32, __PST__UINT8, __PST__UINT8);
typedef __PST__UINT8 __PST__g__56(__PST__UINT8, __PST__UINT8);
struct __PST__g__57
  {
    __PST__UINT8 TarSel;
  };
typedef __PST__g__15 *__PST__g__58;
typedef struct __PST__g__57 *__PST__g__59;
typedef __PST__g__19 *__PST__g__60;
typedef __PST__g__52 *__PST__g__61;
typedef __PST__g__51 *__PST__g__62;
typedef __PST__VOID __PST__g__63(__PST__UINT8, __PST__g__51);
typedef __PST__g__63 *__PST__g__64;
typedef const __PST__g__45 __PST__g__65;
typedef __PST__g__65 *__PST__g__66;
typedef __PST__UINT8 __PST__g__67[4];
typedef const __PST__g__51 __PST__g__68;
typedef __PST__g__68 *__PST__g__69;
typedef __PST__g__53 *__PST__g__70;
typedef __PST__g__32 *__PST__g__71;
typedef const __PST__g__35 __PST__g__72;
typedef __PST__g__72 *__PST__g__73;
typedef const __PST__g__30 __PST__g__74;
typedef __PST__g__74 *__PST__g__75;
typedef __PST__g__67 *__PST__g__76;
typedef __PST__g__55 *__PST__g__77;
typedef const __PST__g__49 __PST__g__78;
typedef __PST__g__78 *__PST__g__79;
typedef const __PST__g__34 __PST__g__80;
typedef __PST__g__80 *__PST__g__81;
typedef const __PST__UINT8 __PST__g__82;
typedef __PST__g__82 *__PST__g__83;
typedef const __PST__g__47 __PST__g__84;
typedef __PST__g__84 *__PST__g__85;
typedef __PST__SINT8 __PST__g__87[1];
struct __PST__g__86
  {
    __PST__UINT32 NvmSampleCnt;
    __PST__g__51 NvmPtr;
    __PST__UINT8 NvmMaxVal;
    __PST__UINT8 NvmMinVal;
    __PST__UINT8 NvmAvrgVal;
    __PST__g__87 __pst_unused_field___pstfiller;
  };
typedef const __PST__UINT16 __PST__g__88;
typedef __PST__g__88 *__PST__g__89;
typedef __PST__g__56 *__PST__g__90;
typedef struct __PST__g__86 *__PST__g__91;
typedef __PST__g__54 *__PST__g__92;
struct __PST__g__93
  {
    __PST__UINT8 TaskId;
  };
typedef struct __PST__g__93 *__PST__g__94;
typedef __PST__g__18 *__PST__g__95;
typedef __PST__VOID __PST__g__96(__PST__g__51, __PST__UINT8, __PST__UINT8, __PST__UINT8, __PST__UINT32);
typedef const __PST__g__24 __PST__g__97;
typedef __PST__g__97 *__PST__g__98;
typedef __PST__g__96 *__PST__g__99;
typedef __PST__g__21 *__PST__g__100;
typedef __PST__g__27 *__PST__g__101;
typedef volatile __PST__SINT32 __PST__g__102;
typedef __PST__SINT8 __PST__g__108(void);
typedef volatile __PST__SINT8 __PST__g__109;
typedef volatile __PST__UINT8 __PST__g__110;
typedef __PST__SINT32 __PST__g__111(void);
typedef __PST__UINT32 __PST__g__112(void);
typedef volatile __PST__UINT32 __PST__g__113;
