#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__SINT32 pst_random_g_4;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct Rte_CDS_CDD_MotAgCmp _main_gen_init_g28(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}

struct Rte_CDS_CDD_MotAgCmp _main_gen_init_g28(void)
{
    static struct Rte_CDS_CDD_MotAgCmp x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_MotAgCmpFirstRunCmpl = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g7();
        }
        x.Pim_MotAgCmpMotAgBackEmf = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__SINT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__SINT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g4();
        }
        x.Pim_MotAgCmpMotCtrlMotAgCumvAlgndMrfRevSVPrev = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__SINT32) / 2];
    }
    /* pointer */
    {
        static __PST__SINT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__SINT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__SINT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g4();
        }
        x.Pim_MotAgCmpMotCtrlMotAgMeclPrev = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__SINT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_CDD_MotAgCmp(void)
{
    extern __PST__g__25 Rte_Inst_CDD_MotAgCmp;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_CDD_MotAgCmp _main_gen_tmp_2[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAgCmp)];
            __PST__UINT32 _i_main_gen_tmp_3;
            for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct Rte_CDS_CDD_MotAgCmp); _i_main_gen_tmp_3++)
            {
                _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g28();
            }
            Rte_Inst_CDD_MotAgCmp = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct Rte_CDS_CDD_MotAgCmp) / 2];
        }
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl(void)
{
    extern __PST__UINT16 MOTCTRLMGR_MotCtrlMotAgMecl;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgMecl = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev(void)
{
    extern __PST__SINT32 MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev;
    
    /* initialization with random value */
    {
        MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev = _main_gen_init_g4();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_CDD_MotAgCmp */
    _main_gen_init_sym_Rte_Inst_CDD_MotAgCmp();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgMecl */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgMecl();
    
    /* init for variable MOTCTRLMGR_MotCtrlMotAgElec : useless (never read) */

    /* init for variable MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev */
    _main_gen_init_sym_MOTCTRLMGR_MotCtrlMotAgCumvAlgndMrfRev();
    
}
