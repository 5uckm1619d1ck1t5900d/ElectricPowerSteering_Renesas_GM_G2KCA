
/* This is just a stub header file for Call_Spi_AsyncTransmit() trusted function */ 

#ifndef _OS_H  /* Multiple include preventer */
#define _OS_H

typedef uint8   Spi_SequenceType;


/* Function prototype */
extern Std_ReturnType Call_Spi_AsyncTransmit(Spi_SequenceType os_arg_Sequence);



#endif 



