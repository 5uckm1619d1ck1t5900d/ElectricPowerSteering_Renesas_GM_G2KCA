#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_AssiMechT_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_AssiMechT_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_FricLrngCustEna_Logl
 */


__PST__UINT8 Rte_Read_SysFricLrng_FricLrngCustEna_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_FricLrngDi_Logl
 */


__PST__UINT8 Rte_Read_SysFricLrng_FricLrngDi_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_HwAg_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_HwAg_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_HwAgAuthy_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_HwAgAuthy_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_HwTq_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_HwTq_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_HwVel_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_HwVel_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_MotTqCmdCrf_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_MotTqCmdCrf_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_VehLatA_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_VehLatA_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_VehSpd_Val
 */


__PST__UINT8 Rte_Read_SysFricLrng_VehSpd_Val(__PST__g__18 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_SysFricLrng_VehSpdVld_Logl
 */


__PST__UINT8 Rte_Read_SysFricLrng_VehSpdVld_Logl(__PST__g__17 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SysFricLrng_MaxLrndFric_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SysFricLrng_MaxLrndFric_Val"


__PST__UINT8 Rte_Write_SysFricLrng_MaxLrndFric_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SysFricLrng_SysFricEstimd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SysFricLrng_SysFricEstimd_Val"


__PST__UINT8 Rte_Write_SysFricLrng_SysFricEstimd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SysFricLrng_SysFricOffs_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SysFricLrng_SysFricOffs_Val"


__PST__UINT8 Rte_Write_SysFricLrng_SysFricOffs_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_SysFricLrng_SysSatnFricEstimd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_SysFricLrng_SysSatnFricEstimd_Val"


__PST__UINT8 Rte_Write_SysFricLrng_SysSatnFricEstimd_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus"


__PST__UINT8 Rte_Call_SysFricLrng_FricLrngData_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus"


__PST__UINT8 Rte_Call_SysFricLrng_FricNonLrngData_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_SysFricLrng_GetRefTmr100MicroSec32bit_Oper(__PST__g__47 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper
 */


__PST__UINT8 Rte_Call_SysFricLrng_GetTiSpan100MicroSec32bit_Oper(__PST__UINT32 P_0, __PST__g__47 P_1)
{
    /* parameter 0 is constant */

    /* parameter 1 */

    if (P_1 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_1[pst_random_int] = pst_random_g_8;
        }
        P_1[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_SysFricLrng_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_SysFricLrng_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_SysFricLrng_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngAvrgFricFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngBasLineEolFric_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngDataPrepLpFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngEolFricDifScagFac_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricDiagcThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricDiagcTiThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngFricOffsLpFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngGain_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngGain_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngGain_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwPosnAuthyThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelConstrLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngHwVelLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngIgnCycFricChgLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngLatAHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngLatALoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngTHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val"


__PST__FLOAT32 Rte_Prm_SysFricLrng_SysFricLrngTLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngThd_Val"


__PST__UINT32 Rte_Prm_SysFricLrng_SysFricLrngThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val"


__PST__UINT16 Rte_Prm_SysFricLrng_SysFricLrngRngCntrThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D"


__PST__g__61 Rte_Prm_SysFricLrng_SysFricLrngBasLineFric_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__61 real_random_for_return ;
        __PST__g__61 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D"


__PST__g__61 Rte_Prm_SysFricLrng_SysFricLrngBasLineHys_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__61 real_random_for_return ;
        __PST__g__61 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D"


__PST__g__64 Rte_Prm_SysFricLrng_SysFricLrngBasLineRngCntr_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__64 real_random_for_return ;
        __PST__g__64 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D"


__PST__g__61 Rte_Prm_SysFricLrng_SysFricLrngFricChgWght_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__61 real_random_for_return ;
        __PST__g__61 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D"


__PST__g__61 Rte_Prm_SysFricLrng_SysFricLrngFricHysHwAgPt_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__61 real_random_for_return ;
        __PST__g__61 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D"


__PST__g__64 Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__64 real_random_for_return ;
        __PST__g__64 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D"


__PST__g__64 Rte_Prm_SysFricLrng_SysFricLrngIvsTrsmRatY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__64 real_random_for_return ;
        __PST__g__64 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D"


__PST__g__67 Rte_Prm_SysFricLrng_SysFricLrngMaskVehSpd_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__67 real_random_for_return ;
        __PST__g__67 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D"


__PST__g__61 Rte_Prm_SysFricLrng_SysFricLrngVehSpd_Ary2D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__61 real_random_for_return ;
        __PST__g__61 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__64 P_0, __PST__g__64 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

