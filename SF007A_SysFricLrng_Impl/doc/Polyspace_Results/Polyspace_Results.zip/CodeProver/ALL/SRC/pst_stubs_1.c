#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__45 _main_gen_init_g45(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__39 _main_gen_init_g39(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__33 _main_gen_init_g33(void);

extern struct Rte_CDS_SysFricLrng _main_gen_init_g31(void);

struct __PST__g__33 _main_gen_init_g33(void)
{
    static struct __PST__g__33 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct __PST__g__39 _main_gen_init_g39(void)
{
    static struct __PST__g__39 x;
    /* struct/union type */
    { /* array type */
        __PST__UINT32 _main_gen_tmp_36_0;
        
        for (_main_gen_tmp_36_0 = 0; _main_gen_tmp_36_0 < 4; _main_gen_tmp_36_0++)
        {
            /* base type */
            x.VehLrndFric[_main_gen_tmp_36_0] = pst_random_g_10;
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_37_0;
        
        for (_main_gen_tmp_37_0 = 0; _main_gen_tmp_37_0 < 8; _main_gen_tmp_37_0++)
        {
            __PST__UINT32 _main_gen_tmp_37_1;
            
            for (_main_gen_tmp_37_1 = 0; _main_gen_tmp_37_1 < 4; _main_gen_tmp_37_1++)
            {
                /* base type */
                x.Hys[_main_gen_tmp_37_0][_main_gen_tmp_37_1] = pst_random_g_10;
            }
        }
    }
    { /* array type */
        __PST__UINT32 _main_gen_tmp_38_0;
        
        for (_main_gen_tmp_38_0 = 0; _main_gen_tmp_38_0 < 8; _main_gen_tmp_38_0++)
        {
            __PST__UINT32 _main_gen_tmp_38_1;
            
            for (_main_gen_tmp_38_1 = 0; _main_gen_tmp_38_1 < 3; _main_gen_tmp_38_1++)
            {
                /* base type */
                x.RngCntr[_main_gen_tmp_38_0][_main_gen_tmp_38_1] = pst_random_g_7;
            }
        }
    }
    x.FricOffs = _main_gen_init_g10();
    x.SysFricLrngOperMod = _main_gen_init_g6();
    return x;
}

struct __PST__g__45 _main_gen_init_g45(void)
{
    static struct __PST__g__45 x;
    /* struct/union type */
    x.EolFric = _main_gen_init_g10();
    x.EnaFricLrng = _main_gen_init_g6();
    x.EnaFricOffsOutp = _main_gen_init_g6();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

struct Rte_CDS_SysFricLrng _main_gen_init_g31(void)
{
    static struct Rte_CDS_SysFricLrng x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_12[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g33();
        }
        x.Pim_AssiMechTLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g33();
        }
        x.Pim_AvrgFricLpFil1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_16[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g33();
        }
        x.Pim_AvrgFricLpFil2 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g33();
        }
        x.Pim_AvrgFricLpFil3 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g33();
        }
        x.Pim_AvrgFricLpFil4 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__g__35 _main_gen_tmp_22[ARRAY_NBELEM(__PST__g__35)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__g__35); _i_main_gen_tmp_23++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_24_0;
                
                for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 12; _main_gen_tmp_24_0++)
                {
                    /* base type */
                    _main_gen_tmp_22[_i_main_gen_tmp_23][_main_gen_tmp_24_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_ColTqAry = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__g__35) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_25[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_26;
        for (_i_main_gen_tmp_26 = 0; _i_main_gen_tmp_26 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_26++)
        {
            _main_gen_tmp_25[_i_main_gen_tmp_26] = _main_gen_init_g33();
        }
        x.Pim_ColTqLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_25[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_27[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_28;
        for (_i_main_gen_tmp_28 = 0; _i_main_gen_tmp_28 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_28++)
        {
            _main_gen_tmp_27[_i_main_gen_tmp_28] = _main_gen_init_g10();
        }
        x.Pim_EstimdFric = PST_TRUE() ? 0 : &_main_gen_tmp_27[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_29[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_30;
        for (_i_main_gen_tmp_30 = 0; _i_main_gen_tmp_30 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_30++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_31_0;
                
                for (_main_gen_tmp_31_0 = 0; _main_gen_tmp_31_0 < 4; _main_gen_tmp_31_0++)
                {
                    /* base type */
                    _main_gen_tmp_29[_i_main_gen_tmp_30][_main_gen_tmp_31_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_FilAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_29[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_32[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g33();
        }
        x.Pim_FricChgLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__39 _main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__39)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(struct __PST__g__39); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g39();
        }
        x.Pim_FricLrngData = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(struct __PST__g__39) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_39[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_40;
        for (_i_main_gen_tmp_40 = 0; _i_main_gen_tmp_40 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_40++)
        {
            _main_gen_tmp_39[_i_main_gen_tmp_40] = _main_gen_init_g6();
        }
        x.Pim_FricLrngOperModPrev = PST_TRUE() ? 0 : &_main_gen_tmp_39[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_41[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_42;
        for (_i_main_gen_tmp_42 = 0; _i_main_gen_tmp_42 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_42++)
        {
            _main_gen_tmp_41[_i_main_gen_tmp_42] = _main_gen_init_g6();
        }
        x.Pim_FricLrngRunOneTi = PST_TRUE() ? 0 : &_main_gen_tmp_41[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__45 _main_gen_tmp_43[ARRAY_NBELEM(struct __PST__g__45)];
        __PST__UINT32 _i_main_gen_tmp_44;
        for (_i_main_gen_tmp_44 = 0; _i_main_gen_tmp_44 < ARRAY_NBELEM(struct __PST__g__45); _i_main_gen_tmp_44++)
        {
            _main_gen_tmp_43[_i_main_gen_tmp_44] = _main_gen_init_g45();
        }
        x.Pim_FricNonLrngData = PST_TRUE() ? 0 : &_main_gen_tmp_43[ARRAY_NBELEM(struct __PST__g__45) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_46;
        for (_i_main_gen_tmp_46 = 0; _i_main_gen_tmp_46 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_46++)
        {
            _main_gen_tmp_45[_i_main_gen_tmp_46] = _main_gen_init_g10();
        }
        x.Pim_FricOffs = PST_TRUE() ? 0 : &_main_gen_tmp_45[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_47[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_48;
        for (_i_main_gen_tmp_48 = 0; _i_main_gen_tmp_48 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_48++)
        {
            _main_gen_tmp_47[_i_main_gen_tmp_48] = _main_gen_init_g6();
        }
        x.Pim_FricOffsOutpDi = PST_TRUE() ? 0 : &_main_gen_tmp_47[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_49[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_50;
        for (_i_main_gen_tmp_50 = 0; _i_main_gen_tmp_50 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_50++)
        {
            _main_gen_tmp_49[_i_main_gen_tmp_50] = _main_gen_init_g33();
        }
        x.Pim_HwAgAuthyLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_49[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__g__35 _main_gen_tmp_51[ARRAY_NBELEM(__PST__g__35)];
        __PST__UINT32 _i_main_gen_tmp_52;
        for (_i_main_gen_tmp_52 = 0; _i_main_gen_tmp_52 < ARRAY_NBELEM(__PST__g__35); _i_main_gen_tmp_52++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_53_0;
                
                for (_main_gen_tmp_53_0 = 0; _main_gen_tmp_53_0 < 12; _main_gen_tmp_53_0++)
                {
                    /* base type */
                    _main_gen_tmp_51[_i_main_gen_tmp_52][_main_gen_tmp_53_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_HwAgBuf = PST_TRUE() ? 0 : &_main_gen_tmp_51[ARRAY_NBELEM(__PST__g__35) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_54[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g33();
        }
        x.Pim_HwAgLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__g__35 _main_gen_tmp_56[ARRAY_NBELEM(__PST__g__35)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__g__35); _i_main_gen_tmp_57++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_58_0;
                
                for (_main_gen_tmp_58_0 = 0; _main_gen_tmp_58_0 < 12; _main_gen_tmp_58_0++)
                {
                    /* base type */
                    _main_gen_tmp_56[_i_main_gen_tmp_57][_main_gen_tmp_58_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_HwVelBuf = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__g__35) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_59[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_60;
        for (_i_main_gen_tmp_60 = 0; _i_main_gen_tmp_60 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_60++)
        {
            _main_gen_tmp_59[_i_main_gen_tmp_60] = _main_gen_init_g33();
        }
        x.Pim_HwVelLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_59[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_61[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_62;
        for (_i_main_gen_tmp_62 = 0; _i_main_gen_tmp_62 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_62++)
        {
            _main_gen_tmp_61[_i_main_gen_tmp_62] = _main_gen_init_g33();
        }
        x.Pim_LatALpFil = PST_TRUE() ? 0 : &_main_gen_tmp_61[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_63[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_64;
        for (_i_main_gen_tmp_64 = 0; _i_main_gen_tmp_64 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_64++)
        {
            _main_gen_tmp_63[_i_main_gen_tmp_64] = _main_gen_init_g10();
        }
        x.Pim_PrevFricOffs = PST_TRUE() ? 0 : &_main_gen_tmp_63[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_65[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_66;
        for (_i_main_gen_tmp_66 = 0; _i_main_gen_tmp_66 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_66++)
        {
            _main_gen_tmp_65[_i_main_gen_tmp_66] = _main_gen_init_g10();
        }
        x.Pim_PrevMaxRawAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_65[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_67[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_68;
        for (_i_main_gen_tmp_68 = 0; _i_main_gen_tmp_68 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_68++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_69_0;
                
                for (_main_gen_tmp_69_0 = 0; _main_gen_tmp_69_0 < 4; _main_gen_tmp_69_0++)
                {
                    /* base type */
                    _main_gen_tmp_67[_i_main_gen_tmp_68][_main_gen_tmp_69_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_RawAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_67[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_71++)
        {
            _main_gen_tmp_70[_i_main_gen_tmp_71] = _main_gen_init_g8();
        }
        x.Pim_RefTmrLrngConstr = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_73;
        for (_i_main_gen_tmp_73 = 0; _i_main_gen_tmp_73 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_73++)
        {
            _main_gen_tmp_72[_i_main_gen_tmp_73] = _main_gen_init_g8();
        }
        x.Pim_RefTmrNtc = PST_TRUE() ? 0 : &_main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_74[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_75;
        for (_i_main_gen_tmp_75 = 0; _i_main_gen_tmp_75 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_75++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_76_0;
                
                for (_main_gen_tmp_76_0 = 0; _main_gen_tmp_76_0 < 4; _main_gen_tmp_76_0++)
                {
                    /* base type */
                    _main_gen_tmp_74[_i_main_gen_tmp_75][_main_gen_tmp_76_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_SatnAvrgFric = PST_TRUE() ? 0 : &_main_gen_tmp_74[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_78;
        for (_i_main_gen_tmp_78 = 0; _i_main_gen_tmp_78 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_78++)
        {
            _main_gen_tmp_77[_i_main_gen_tmp_78] = _main_gen_init_g10();
        }
        x.Pim_SatnEstimdFric = PST_TRUE() ? 0 : &_main_gen_tmp_77[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__g__37 _main_gen_tmp_79[ARRAY_NBELEM(__PST__g__37)];
        __PST__UINT32 _i_main_gen_tmp_80;
        for (_i_main_gen_tmp_80 = 0; _i_main_gen_tmp_80 < ARRAY_NBELEM(__PST__g__37); _i_main_gen_tmp_80++)
        {
            { /* array type */
                __PST__UINT32 _main_gen_tmp_81_0;
                
                for (_main_gen_tmp_81_0 = 0; _main_gen_tmp_81_0 < 4; _main_gen_tmp_81_0++)
                {
                    /* base type */
                    _main_gen_tmp_79[_i_main_gen_tmp_80][_main_gen_tmp_81_0] = pst_random_g_10;
                }
            }
        }
        x.Pim_VehBasLineFric = PST_TRUE() ? 0 : &_main_gen_tmp_79[ARRAY_NBELEM(__PST__g__37) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__33 _main_gen_tmp_82[ARRAY_NBELEM(struct __PST__g__33)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(struct __PST__g__33); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g33();
        }
        x.Pim_VehSpdLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(struct __PST__g__33) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_SysFricLrng(void)
{
    extern __PST__g__28 Rte_Inst_SysFricLrng;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_SysFricLrng _main_gen_tmp_10[ARRAY_NBELEM(struct Rte_CDS_SysFricLrng)];
            __PST__UINT32 _i_main_gen_tmp_11;
            for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(struct Rte_CDS_SysFricLrng); _i_main_gen_tmp_11++)
            {
                _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g31();
            }
            Rte_Inst_SysFricLrng = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(struct Rte_CDS_SysFricLrng) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_SysFricLrng */
    _main_gen_init_sym_Rte_Inst_SysFricLrng();
    
}
