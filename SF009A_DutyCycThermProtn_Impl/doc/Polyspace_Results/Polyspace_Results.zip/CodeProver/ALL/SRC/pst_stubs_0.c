#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_DiagcStsLimdTPrfmnc_Logl
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_DiagcStsLimdTPrfmnc_Logl(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_DualEcuFltMtgtnEna_Logl
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_DualEcuFltMtgtnEna_Logl(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_DutyCycThermProtnDi_Logl
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_DutyCycThermProtnDi_Logl(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_EcuTFild_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_EcuTFild_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_IgnTiOff_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_IgnTiOff_Val(__PST__g__38 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_8;
        }
        P_0[0] = pst_random_g_8;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_IvtrLoaMtgtnEna_Logl
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_IvtrLoaMtgtnEna_Logl(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotCurrPeakEstimd_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotCurrPeakEstimd_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotCurrPeakEstimdFild_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotCurrPeakEstimdFild_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotFetT_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotFetT_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotMagT_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotMagT_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotVelCrf_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotVelCrf_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_MotWidgT_Val
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_MotWidgT_Val(__PST__g__26 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_DutyCycThermProtn_VehTiVld_Logl
 */


__PST__UINT8 Rte_Read_DutyCycThermProtn_VehTiVld_Logl(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_DutyCycThermProtnMaxOutp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_DutyCycThermProtnMaxOutp_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_DutyCycThermProtnMaxOutp_Val(__PST__UINT16 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_ThermDutyCycProtnLoadDptLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_ThermDutyCycProtnLoadDptLim_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_ThermDutyCycProtnLoadDptLim_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_ThermDutyCycProtnTDptLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_ThermDutyCycProtnTDptLim_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_ThermDutyCycProtnTDptLim_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_ThermLimSlowFilMax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_ThermLimSlowFilMax_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_ThermLimSlowFilMax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_ThermMotTqLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_ThermMotTqLim_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_ThermMotTqLim_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_DutyCycThermProtn_ThermRednFac_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_DutyCycThermProtn_ThermRednFac_Val"


__PST__UINT8 Rte_Write_DutyCycThermProtn_ThermRednFac_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DutyCycThermProtn_FilStVal_GetErrorStatus
 */


__PST__UINT8 Rte_Call_DutyCycThermProtn_FilStVal_GetErrorStatus(__PST__g__29 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DutyCycThermProtn_FilStVal_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_DutyCycThermProtn_FilStVal_SetRamBlockStatus"


__PST__UINT8 Rte_Call_DutyCycThermProtn_FilStVal_SetRamBlockStatus(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DutyCycThermProtn_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_DutyCycThermProtn_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_DutyCycThermProtn_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltMotVelBreakPt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltMotVelBreakPt_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltMotVelBreakPt_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewHiLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewHiLim_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewHiLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewLoLim_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewLoLim_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltTTqSlewLoLim_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlT_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlT_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlT_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffMsgWaitTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffMsgWaitTi_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffMsgWaitTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLimScaFac_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLimScaFac_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLimScaFac_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewDwn_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewDwn_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewDwn_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewUp_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewUp_Val"


__PST__FLOAT32 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnTqCmdSlewUp_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnDutyCycFildThd_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnDutyCycFildThd_Val"


__PST__UINT16 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnDutyCycFildThd_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlTSeln_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlTSeln_Logl"


__PST__UINT8 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnCtrlTSeln_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffCtrlEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffCtrlEna_Logl"


__PST__UINT8 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnIgnOffCtrlEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMotPrTSeln_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMotPrTSeln_Logl"


__PST__UINT8 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMotPrTSeln_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTSeln_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTSeln_Logl"


__PST__UINT8 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTSeln_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnSlowFilTSeln_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnSlowFilTSeln_Logl"


__PST__UINT8 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnSlowFilTSeln_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTblX_Ary1D"


__PST__g__47 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__47 real_random_for_return ;
        __PST__g__47 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTqTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTqTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCtrlTTqTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTblX_Ary1D"


__PST__g__47 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__47 real_random_for_return ;
        __PST__g__47 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTqTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTqTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnAbsltCuTTqTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValNonStall_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValNonStall_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValNonStall_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValStall_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValStall_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnLstTblValStall_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr1StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr2StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr3StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr4StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr5StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6NonStallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6NonStallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6NonStallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6StallTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6StallTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplr6StallTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTblX_Ary1D"


__PST__g__47 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnMplrTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__47 real_random_for_return ;
        __PST__g__47 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblX_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblY_Ary1D"


__PST__g__50 Rte_Prm_DutyCycThermProtn_DutyCycThermProtnThermLoadLimTblY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__50 real_random_for_return ;
        __PST__g__50 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_IrvWrite_DutyCycThermProtn_DutyCycThermProtnInit1_FilStVariReInitFlg
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvWrite_DutyCycThermProtn_DutyCycThermProtnInit1_FilStVariReInitFlg"


__PST__VOID Rte_IrvWrite_DutyCycThermProtn_DutyCycThermProtnInit1_FilStVariReInitFlg(__PST__UINT8 P_0)
{
    /* function is pure */

    return;
}

/*
 * Rte_IrvRead_DutyCycThermProtn_DutyCycThermProtnPer1_FilStVariReInitFlg
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_IrvRead_DutyCycThermProtn_DutyCycThermProtnPer1_FilStVariReInitFlg"


__PST__UINT8 Rte_IrvRead_DutyCycThermProtn_DutyCycThermProtnPer1_FilStVariReInitFlg(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__50 P_0, __PST__g__50 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_s16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_s16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_s16VariXu16VariY(__PST__g__47 P_0, __PST__g__50 P_1, __PST__UINT16 P_2, __PST__SINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

