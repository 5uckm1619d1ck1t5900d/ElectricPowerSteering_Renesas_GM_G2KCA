#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct __PST__g__28 _main_gen_init_g28(void);

extern struct Rte_CDS_HysCmp _main_gen_init_g26(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

struct __PST__g__28 _main_gen_init_g28(void)
{
    static struct __PST__g__28 x;
    /* struct/union type */
    x.FilSt = _main_gen_init_g10();
    x.FilGain = _main_gen_init_g10();
    return x;
}

struct Rte_CDS_HysCmp _main_gen_init_g26(void)
{
    static struct Rte_CDS_HysCmp x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__28 _main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__28)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(struct __PST__g__28); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g28();
        }
        x.Pim_AssiCmdLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(struct __PST__g__28) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__28 _main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__28)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(struct __PST__g__28); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g28();
        }
        x.Pim_FinalOutpLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(struct __PST__g__28) / 2];
    }
    /* pointer */
    {
        static struct __PST__g__28 _main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__28)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(struct __PST__g__28); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g28();
        }
        x.Pim_HwTqLpFil = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(struct __PST__g__28) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g10();
        }
        x.Pim_PrevAssiCmdFildVal = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g10();
        }
        x.Pim_PrevHwTqFildVal = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g10();
        }
        x.Pim_PrevRiseX = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g10();
        }
        x.Pim_PrevRiseY = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpAssiCmdFild = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpAvl = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpEffCmpTq = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpFric = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpHwTqFild = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpNegAvl = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_28[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpPosAvl = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_30[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpRawVal = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_32[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g10();
        }
        x.Pim_dHysCmpRiseYFac = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_HysCmp(void)
{
    extern __PST__g__23 Rte_Inst_HysCmp;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_HysCmp _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_HysCmp)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_HysCmp); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g26();
            }
            Rte_Inst_HysCmp = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_HysCmp) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_HysCmp */
    _main_gen_init_sym_Rte_Inst_HysCmp();
    
}
