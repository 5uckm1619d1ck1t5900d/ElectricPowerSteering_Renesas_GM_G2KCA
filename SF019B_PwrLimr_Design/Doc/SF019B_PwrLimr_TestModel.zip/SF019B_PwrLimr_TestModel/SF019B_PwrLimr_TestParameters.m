


PwrLimrPer1 = 0.002;
PwrLimrPer2 = 0.01;

%% Inputs
AltFltActv = 0;
BrdgVltg =13.5; 
% DualEcuFltMtgtnSca =1;
DualEcuFltMtgtnSca =0;
IvtrLoaMtgtnEna =0; 
MotBackEmfConEstimd =0.0335999; 
MotTqCmdMrf = 0.5; 
MotVelMrf = 100; 

%%-------------------------------------------
PwrLimrAssiRednLpFilFrq =0.365; 
PwrLimrBackEmfConStdT = 0.0335999;
PwrLimrBrdgVltgAdjSlew = 0.5;
PwrLimrBrdgVltgAltFltAdj =  1;
PwrLimrFilAssiRednThd = 0.6;
PwrLimrLoVoltAssiRcvrThd = 13.5;
PwrLimrLoVoltAssiRcvrTi =2000; 
PwrLimrMotEnvlpX = [-1100             -800             -650             -550        -353.5625           -287.5        -218.6875        -108.1875                0         108.1875         218.6875            287.5         353.5625              550];
PwrLimrMotEnvlpY =  [0.7202148         1.399902         1.899902         2.299805              3.5         4.100098         4.631836         4.631836         4.631836         4.631836         3.553223         2.926758         2.200195                0];
PwrLimrMotVelLpFilFrq = 100; 
PwrLimrSpdAdjSlewDec = 3.125;
PwrLimrSpdAdjSlewEna =1; 
PwrLimrSpdAdjSlewInc = 3125;
PwrLimrStdOperMotEnvlpX =[0          68.1875         178.6563         247.4688         313.5625              510]; 
PwrLimrStdOperMotEnvlpY = [4.63208          4.63208         3.552979         2.927002         2.199951                0];
PwrLimrVltgDptMotVelOffsX = [8.542969         9.144531         9.242188          9.34375         9.441406         9.542969         10.04297         10.54297         10.84375         12.34375];
PwrLimrVltgDptMotVelOffsY = [106.0938         89.34375         86.53125            83.75         80.96875         78.15625          64.1875            50.25           41.875                0];




ARCHGLBPRM_10MILLISEC_SEC_F32 = 0.01;
ARCHGLBPRM_2MILLISEC_SEC_F32 =  0.002;
ELECGLBPRM_IVTRCNT_CNT_U08 =1; 
PWRLIMRMILLISECTOSEC_SECPERMILLISEC_F32 = 0.001; 
PWRLIMRTQLIMHILIM_ULS_F32 = 1;
PWRLIMRTQLIMLOLIM_ULS_F32 = 0;
SYSGLBPRM_MOTTQCMDHILIM_MOTNWTMTR_F32 = 8.8;
SYSGLBPRM_MOTTQCMDLOLIM_MOTNWTMTR_F32 = -8.8;



