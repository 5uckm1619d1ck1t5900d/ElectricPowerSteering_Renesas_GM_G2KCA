/**********************************************************************************************************************
* Copyright 2014 Nexteer 
* Nexteer Confidential
*
* Module File Name  : Renesas_Compiler.h
* Module Description: This file contains a stub header for UTP and QAC 
*                     projects
* Project           : CBD
* Author            : Lucas Wendling
***********************************************************************************************************************
* Version Control:
* %version:          1 %
* %derived_by:       czgng4 %
*----------------------------------------------------------------------------
* Date      Rev      Author         Change Description
* -------   -------  --------  ----------------------------------------------
* 12/18/15  1.0      LWW       Initial EA4 version
**********************************************************************************************************************/
#ifndef RENESAS_COMPILER_H
#define RENESAS_COMPILER_H


#endif  /* RENESAS_COMPILER_H */

