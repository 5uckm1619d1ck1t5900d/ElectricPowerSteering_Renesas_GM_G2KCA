
#ifndef FLTINJ_H
#define FLTINJ_H

/* Fault Injection Command */
#define FLTINJ_HWAGSYSARBN_HWAG                 (23U)
#define FLTINJ_HWAGSYSARBN_SERLCOMHWAG  (37U)

#endif

