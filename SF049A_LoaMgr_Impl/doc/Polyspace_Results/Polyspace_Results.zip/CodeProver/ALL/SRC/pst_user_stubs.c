/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_LoaMgr_CurrMeasIdptSig_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_CurrMeasIdptSig_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_CurrMeasIdptSig_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_CurrMeasIdptSig_Val"
//
// __PST__UINT8 Rte_Read_LoaMgr_CurrMeasIdptSig_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_DiagcStsIvtr1Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_DiagcStsIvtr1Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_DiagcStsIvtr1Inactv_Logl"
//
// __PST__UINT8 Rte_Read_LoaMgr_DiagcStsIvtr1Inactv_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_DiagcStsIvtr2Inactv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_DiagcStsIvtr2Inactv_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_DiagcStsIvtr2Inactv_Logl"
//
// __PST__UINT8 Rte_Read_LoaMgr_DiagcStsIvtr2Inactv_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_HwTqIdptSig_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_HwTqIdptSig_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_HwTqIdptSig_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_HwTqIdptSig_Val"
//
// __PST__UINT8 Rte_Read_LoaMgr_HwTqIdptSig_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_LoaScaDi_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_LoaScaDi_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_LoaScaDi_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_LoaScaDi_Logl"
//
// __PST__UINT8 Rte_Read_LoaMgr_LoaScaDi_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_MotAgMeclIdptSig_Val
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_MotAgMeclIdptSig_Val"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_MotAgMeclIdptSig_Val"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_MotAgMeclIdptSig_Val"
//
// __PST__UINT8 Rte_Read_LoaMgr_MotAgMeclIdptSig_Val(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Read_LoaMgr_TqLoaAvl_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_LoaMgr_TqLoaAvl_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_LoaMgr_TqLoaAvl_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_LoaMgr_TqLoaAvl_Logl"
//
// __PST__UINT8 Rte_Read_LoaMgr_TqLoaAvl_Logl(__PST__g__26 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_CurrMeasLoaMtgtnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_CurrMeasLoaMtgtnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_CurrMeasLoaMtgtnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_CurrMeasLoaMtgtnEna_Logl"
//
// __PST__UINT8 Rte_Write_LoaMgr_CurrMeasLoaMtgtnEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_HwTqLoaMtgtnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_HwTqLoaMtgtnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_HwTqLoaMtgtnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_HwTqLoaMtgtnEna_Logl"
//
// __PST__UINT8 Rte_Write_LoaMgr_HwTqLoaMtgtnEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_IvtrLoaMtgtnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_IvtrLoaMtgtnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_IvtrLoaMtgtnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_IvtrLoaMtgtnEna_Logl"
//
// __PST__UINT8 Rte_Write_LoaMgr_IvtrLoaMtgtnEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_LoaRateLim_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_LoaRateLim_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_LoaRateLim_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_LoaRateLim_Val"
//
// __PST__UINT8 Rte_Write_LoaMgr_LoaRateLim_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_LoaSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_LoaSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_LoaSca_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_LoaSca_Val"
//
// __PST__UINT8 Rte_Write_LoaMgr_LoaSca_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_LoaSt_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_LoaSt_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_LoaSt_Val"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_LoaSt_Val"
//
// __PST__UINT8 Rte_Write_LoaMgr_LoaSt_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_LoaMgr_MotAgLoaMtgtnEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_LoaMgr_MotAgLoaMtgtnEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_LoaMgr_MotAgLoaMtgtnEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_LoaMgr_MotAgLoaMtgtnEna_Logl"
//
// __PST__UINT8 Rte_Write_LoaMgr_MotAgLoaMtgtnEna_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_LoaMgr_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_LoaMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_LoaMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_LoaMgr_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_LoaMgr_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnSca_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnSca_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrFadeOutStRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrFadeOutStRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrFadeOutStRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrFadeOutStRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrFadeOutStRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnSca_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrLimdStRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrLimdStRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrLimdStRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrLimdStRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrLimdStRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrLimdStSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrLimdStSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrLimdStSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrLimdStSca_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrLimdStSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnRate_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnRate_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnRate_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnRate_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnRate_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnSca_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnSca_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnSca_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnSca_Val"
//
// __PST__FLOAT32 Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnSca_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig0Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig0Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig0Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig0Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig0Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig1Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig1Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig1Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig1Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig1Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig2Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig2Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig2Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig2Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSig2Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSigFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSigFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSigFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSigFltThd_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrMeasIdptSigFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig0NoTqLoaResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig0NoTqLoaResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig0NoTqLoaResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig0NoTqLoaResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig0NoTqLoaResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig1NoTqLoaResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig1NoTqLoaResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig1NoTqLoaResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig1NoTqLoaResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig1NoTqLoaResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig2Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig2Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig2Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig2Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig2Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig4Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig4Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig4Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig4Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqIdptSig4Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqIdptSigFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSigFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSigFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqIdptSigFltThd_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqIdptSigFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrHwTqLoaAvlResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrHwTqLoaAvlResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrHwTqLoaAvlResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrHwTqLoaAvlResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrHwTqLoaAvlResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig0Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig0Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig0Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig0Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig0Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig1Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig1Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig1Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig1Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig1Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig2Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig2Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig2Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig2Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrIvtrIdptSig2Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrIdptSigFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSigFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSigFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrIdptSigFltThd_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrIvtrIdptSigFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgAvlSnsrlsResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgAvlSnsrlsResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgAvlSnsrlsResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgAvlSnsrlsResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgAvlSnsrlsResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig0NoSnsrlsResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig0NoSnsrlsResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig0NoSnsrlsResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig0NoSnsrlsResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig0NoSnsrlsResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig1NoSnsrlsResp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig1NoSnsrlsResp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig1NoSnsrlsResp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig1NoSnsrlsResp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig1NoSnsrlsResp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig2Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig2Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig2Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig2Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig2Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig3Resp_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig3Resp_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig3Resp_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig3Resp_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgIdptSig3Resp_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgIdptSigFltThd_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSigFltThd_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSigFltThd_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgIdptSigFltThd_Val"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgIdptSigFltThd_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnScaZeroEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnScaZeroEna_Logl"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrIvtrMtgtnScaZeroEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnScaZeroEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnScaZeroEna_Logl"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrCurrMeasMtgtnScaZeroEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnScaZeroEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnScaZeroEna_Logl"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrIvtrMtgtnScaZeroEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnScaZeroEna_Logl
//
// #pragma POLYSPACE_PURE "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnScaZeroEna_Logl"
// #pragma POLYSPACE_WORST "Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnScaZeroEna_Logl"
//
// __PST__UINT8 Rte_Prm_LoaMgr_LoaMgrMotAgMtgtnScaZeroEna_Logl(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_IrvWrite_LoaMgr_LoaMgrInit1_SnsrlsMotAgAvl
//
// #pragma POLYSPACE_PURE "Rte_IrvWrite_LoaMgr_LoaMgrInit1_SnsrlsMotAgAvl"
// #pragma POLYSPACE_CLEAN "Rte_IrvWrite_LoaMgr_LoaMgrInit1_SnsrlsMotAgAvl"
// #pragma POLYSPACE_WORST "Rte_IrvWrite_LoaMgr_LoaMgrInit1_SnsrlsMotAgAvl"
//
// __PST__VOID Rte_IrvWrite_LoaMgr_LoaMgrInit1_SnsrlsMotAgAvl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_IrvRead_LoaMgr_LoaMgrPer1_SnsrlsMotAgAvl
//
// #pragma POLYSPACE_PURE "Rte_IrvRead_LoaMgr_LoaMgrPer1_SnsrlsMotAgAvl"
// #pragma POLYSPACE_CLEAN "Rte_IrvRead_LoaMgr_LoaMgrPer1_SnsrlsMotAgAvl"
// #pragma POLYSPACE_WORST "Rte_IrvRead_LoaMgr_LoaMgrPer1_SnsrlsMotAgAvl"
//
// __PST__UINT8 Rte_IrvRead_LoaMgr_LoaMgrPer1_SnsrlsMotAgAvl(__PST__VOID)
// {
//    ...
// }

