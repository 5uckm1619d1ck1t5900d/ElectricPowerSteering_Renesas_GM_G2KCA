#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__FLOAT32 pst_random_g_10;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * expf
 */

#pragma POLYSPACE_POLYMORPHIC "expf"


__PST__FLOAT32 expf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * fabsf
 */

#pragma POLYSPACE_POLYMORPHIC "fabsf"


__PST__FLOAT32 fabsf(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_CurrMeasLoaMtgtnEna_Logl
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_CurrMeasLoaMtgtnEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_DualEcuMotCtrlMtgtnEna_Logl
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_DualEcuMotCtrlMtgtnEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_IvtrLoaMtgtnEna_Logl
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_IvtrLoaMtgtnEna_Logl(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_MotCurrEolCalSt_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_MotCurrEolCalSt_Val(__PST__g__32 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_MotInduDaxEstimd_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_MotInduDaxEstimd_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_MotInduQaxEstimd_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_MotInduQaxEstimd_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_MotREstimd_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_MotREstimd_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_MotVelMrf_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_MotVelMrf_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Read_MotCurrRegCfg_VehSpd_Val
 */


__PST__UINT8 Rte_Read_MotCurrRegCfg_VehSpd_Val(__PST__g__28 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_10;
        }
        P_0[0] = pst_random_g_10;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotAgElecDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotAgElecDly_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotAgElecDly_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotDampgDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotDampgDax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotDampgDax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotDampgQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotDampgQax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotDampgQax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotIntglGainDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotIntglGainDax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotIntglGainDax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotIntglGainQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotIntglGainQax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotIntglGainQax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotPropGainDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotPropGainDax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotPropGainDax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_MotCurrRegCfg_MotPropGainQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_MotCurrRegCfg_MotPropGainQax_Val"


__PST__UINT8 Rte_Write_MotCurrRegCfg_MotPropGainQax_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCtrlrDynGainVehSpdCutOff_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCtrlrDynGainVehSpdCutOff_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCtrlrDynGainVehSpdCutOff_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgIntglGainSampleTi_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgIntglGainSampleTi_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgIntglGainSampleTi_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotAgCompuDly_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotAgCompuDly_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotAgCompuDly_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatDax_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatDax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatQax_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotDampgRatQax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtDax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtDax_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtDax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtQax_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtQax_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotRVirtQax_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotVelFilFrq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotVelFilFrq_Val"


__PST__FLOAT32 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotVelFilFrq_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__FLOAT32 real_random_for_return  = 0;
        __PST__FLOAT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_SysGlbPrmMotPoleCnt_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_SysGlbPrmMotPoleCnt_Val"


__PST__UINT8 Rte_Prm_MotCurrRegCfg_SysGlbPrmMotPoleCnt_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl"


__PST__UINT8 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgCurrLoopSecOrderTrfFctEna_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotRefMdlFbCtrlDi_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotRefMdlFbCtrlDi_Logl"


__PST__UINT8 Rte_Prm_MotCurrRegCfg_MotRefMdlFbCtrlDi_Logl(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwDaxY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwDaxY_Ary1D"


__PST__g__38 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwDaxY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__38 real_random_for_return ;
        __PST__g__38 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwQaxY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwQaxY_Ary1D"


__PST__g__38 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotClsdLoopBwQaxY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__38 real_random_for_return ;
        __PST__g__38 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotCtrlPrmSelnX_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotCtrlPrmSelnX_Ary1D"


__PST__g__38 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotCtrlPrmSelnX_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__38 real_random_for_return ;
        __PST__g__38 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqDaxY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqDaxY_Ary1D"


__PST__g__38 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqDaxY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__38 real_random_for_return ;
        __PST__g__38 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqQaxY_Ary1D
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqQaxY_Ary1D"


__PST__g__38 Rte_Prm_MotCurrRegCfg_MotCurrRegCfgMotNatFrqQaxY_Ary1D(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__g__38 real_random_for_return ;
        __PST__g__38 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * LnrIntrpn_u16_u16VariXu16VariY
 */

#pragma POLYSPACE_POLYMORPHIC "LnrIntrpn_u16_u16VariXu16VariY"


__PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__38 P_0, __PST__g__38 P_1, __PST__UINT16 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT16 real_random_for_return  = 0;
        __PST__UINT16 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

